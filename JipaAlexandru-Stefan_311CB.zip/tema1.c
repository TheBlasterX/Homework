/* Jipa Alexandru-Stefan - 311CB */
#include "tlg.h"

int main(int args, char *argv[])
{
	FILE *hash_input = fopen(argv[2],"r");
	FILE *hash_output = fopen(argv[3],"w");
	char key[50], value[20], cond[12], *val=malloc(30);
	int M = atoi(argv[1]);	//argumentul este char, dar ne trebuie int
	int nr;
	THTG hashtable = NULL;
	hashtable = alocaHashTable(M);

	for( ; fscanf(hash_input, "%s ", cond) != EOF; )
	{
		if(strcmp(cond, "set") == 0)
		{
			fscanf(hash_input,"%s %s", key, value);
			set(key, value, hashtable);
		}

		if(strcmp(cond, "get") == 0)
		{

			fscanf(hash_input, "%s", key);
			val = get(key, hashtable);
			if (val == NULL)
			{
				fprintf(hash_output, "NULL\n");
			}
			else
			{
			fprintf(hash_output, "%s\n", val);
			}
		}
		
		if(strcmp(cond, "remove") == 0)
		{
			fscanf(hash_input, "%s", key);
			removek(key, hashtable);
		}

		if(strcmp(cond, "print") == 0)
		{	print(hashtable, hash_output);
		}
		
		if(strcmp(cond, "print_list") == 0)
		{
			fscanf(hash_input, "%s", value);
			nr = atoi(value);	//la fel, am nevoie de int
			if(M > nr && nr>= 0)
			{
				print_list(hashtable, hash_output, nr);
			}
		}	
	}
	fclose(hash_input);
	fclose(hash_output);
	return 0;
}
