/* Jipa Alexandru-Stefan - 311CB */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

#ifndef _LISTA_GENERICA_
#define _LISTA_GENERICA_

typedef struct celulag
{ 
  void* info;           /* adresa informatie */
  struct celulag *next, *previous;   /* adresa urmatoarei celule */
} TCelulaG, *TLG, **ALG; /* tipurile Celula, Lista si Adresa_Lista */

typedef struct
{
	TLG *array;			//vector pentru tabela hash
	int M;				//numarul de intrari in tabela hash
} THashTableG, *THTG, **AHTG;

typedef struct { 
	char key[20], value[15];	//key pentru site, value pentru ip
	int Frequency ;		// nr de accesari site
 } Tform; 

typedef int (*TFElem)(void*);     /* functie prelucrare element */
typedef int (*TFCmp)(void*, void*); /* functie de comparare doua elemente */
typedef void (*TFAfi)(void*);     /* functie afisare un element */

void Afi(void *el, FILE *f);
/*- inserare element in lista */
void InsLG(ALG aL, void *a );

void print(THTG hashtable, FILE *f);

void DistrugeLG(ALG); /* eliminare celula si element */

void Distruge(ALG aL); /* distruge lista */

size_t LungimeLG(ALG);   /* numarul de elemente din lista */

/* afiseaza elementele din lista, folosind o functie de tip TFAfi */

void AfiEntry(void * ae);

// fucntion used to comapare key with name from a TEntry struct
int cmpKey(char *key, void *ae);

THTG alocaHashTable(size_t length);

void destroyHashTable(AHTG hashtable);

void print_list(THTG hashtable, FILE *f, int index);

//functie ce calculeaza codul hash
int hash_function(char *key, int M);

int set(char *key, char *value, THTG hashtable);

char *get(char *key, THTG hashtable);

void removek(char *key, THTG hashtable);
        

#endif