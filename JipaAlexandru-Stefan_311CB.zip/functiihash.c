/* Jipa Alexandru-Stefan - 311CB */
#include "tlg.h"

//functie de comparare intre key-uri
int cmpKey(char *key, void *ae)
{
  Tform x = *(Tform*)ae;
  
  return strcmp(key, x.key);
}

//aloca tabela hash si o initializez NULL
THTG alocaHashTable(size_t M)
{
    THTG hashtable = NULL;
    hashtable = malloc(sizeof(THashTableG));
    hashtable->M = M;
    hashtable->array = malloc(M * sizeof(TLG));
    int i;
    for (i = 0; i < M; i++)
        hashtable->array[i] = NULL;

    return hashtable;
}

//functie conform cerintei
//afisez tabela hash
void print(THTG hashtable, FILE *f)
{
    int i;
    ALG LL;
    for (i = 0; i < hashtable->M; i++)
    {
        LL = &hashtable->array[i];
        TLG L=*LL;
        if(L != NULL)
        {   fprintf(f, "%d:", i);
            TLG last = L->previous;
            for(;L != last; L = L->next)
            {
                fprintf(f, " ");
                Afi(L->info, f);
            }
            fprintf(f, " ");
            Afi(L->info, f);
            fprintf(f, "\n");
        }
    }
}  

//afiseaza continutul unei celule
void Afi(void *el, FILE *f)
{
    Tform x = *(Tform*) el; 
    fprintf(f, "(%s)", x.value);
}

//functie conform cerintei, care calculeaza indexul
int hash_function(char *key, int M)
{
    char *s = key;
    int hcode;
    int sum = 0;
    while(*s != 0)
    {
        sum += *s;
        s++;
    }
    hcode = sum % M;
    return hcode;
}

//functie conform cerintei
int set(char *key, char *value, THTG hashtable)
{
    int nr = hash_function(key, hashtable->M);
    TLG L = hashtable->array[nr];
    TLG begin = L;
    if(L == NULL) // In caz ca am lista nula
    {
        Tform *a = malloc(sizeof(Tform));
        int k = strlen(key);
        int v = strlen(value);
        memcpy(a->key, key, k*sizeof(char));
        memcpy(a->value, value, v*sizeof(char));
        InsLG(&hashtable->array[nr], a);
        return 0;
    }
    do
    {
        //petru a verifica daca acest element exista in lista
		//si apoi ies din functie
        if(cmpKey(key,L->info) == 0)       
        {
            return 0;
        }
    L = L->next;        
    }while(L != begin);
//daca lista nu e nula si elementul nu s-a gasit inserez elementrul in lista   
			
    Tform *a = malloc(sizeof(Tform));
    int k = strlen(key);
    int v = strlen(value);
    memcpy(a->key, key, k*sizeof(char));
    memcpy(a->value, value, v*sizeof(char));
    InsLG(&hashtable->array[nr], a);
    return 1;
}

//inserare element in lista
void InsLG(ALG aL, void *a ){
    TLG aux = malloc(sizeof(TCelulaG));
    if(!aux) return;
    //test de alocare
    aux->info = malloc(sizeof(Tform));
    if(!aux->info)
    {
        free(aux);
        return;
    }
    //test de alocare + eliberare
    memcpy(aux->info, a, sizeof(Tform));
    //daca nu am niciun element 
    //fac sa pointeze next si previous la element
    if(*aL == NULL)
    {
        aux->previous = aux;
        aux->next = aux;
        *aL = aux;
        return;
    }
    else if(*aL == (*aL)->next) // lista cu 1 singur element
    {
        aux->next = (*aL);
        aux->previous = (*aL); 
        (*aL)->previous = aux;
        (*aL)->next = aux;
        return;
    }   
    else
    {
    	//lista cu 2 sau mai multe elemente inainte de inserare
        aux->next = (*aL);
        aux->previous = (*aL)->previous;
        (*aL)->previous->next = aux;
        (*aL)->previous = aux; 
        return;
    }
}

//functie conform cerintei
//afiseaza valorile (Value) din lista cu indicele index, pe o singura linie
void print_list(THTG hashtable,FILE *f,int index)
{
    
    ALG ad = &hashtable->array[index];
    TLG ad2L = *ad;
    if(!ad2L)
    {
        fprintf(f, "%d: VIDA\n", index);  //in caz ca lista e vida
        return;
    }
    fprintf(f, "%d: ", index);
    TLG first = (ad2L);
    do
    {
    Afi((ad2L)->info, f);
    ad2L = ad2L->next;
    }while(ad2L != first);
    fprintf(f, "\n");
}

//functie conform cerintei
char *get(char *key, THTG hashtable)
{
    int nr = hash_function(key, hashtable->M);
    TLG L = hashtable->array[nr];
    if (L == NULL) return NULL;
    TLG first = L;

    do
    {
        if(cmpKey(key, L->info) == 0) //caut celula cu key-ul dat
        {

            Tform *b = malloc(sizeof(Tform));
            memcpy(b,L->info, sizeof(Tform)) ;
            return b->value;
        }
    L = L->next;
    }while(L != first);
    
    return NULL;
}

//functie conform cerintei
void removek(char *key, THTG hashtable)
{
    int index = hash_function(key, hashtable->M);
    ALG aL = &hashtable->array[index];
    TLG T=(*aL);
    if(!T) //daca lista e nula nu am ce sterge
    {
        return;
    }
    //daca lista are 1 celula
    if( T == T->next && (cmpKey(key,T->info) == 0))
    {
        free(T->info);
        T = NULL;
        hashtable->array[index] = T;
        return;
    }

    TLG first = *aL;
    TLG aux = (*aL);
        TLG P = (*aL);
    do
    {
        
        if( P == P->next->next) //daca am 2 celule
        {
            if(cmpKey(key,(*aL)->info) == 0) //verifica daca am gasit cheia 
            {
                aux = P;
                P = P->next;
                P->previous = P;
                P->next = P;
                *aL = P;
                free(aux->info);
                free(aux);
                return;
            }

        }
        else if(cmpKey(key,(*aL)->info) == 0)
        {
        	//sterg un element dint-o lista cu mai mult de 2 elemente
            P->previous->next = P->next;
            P->next->previous = P->previous;
        }
        P = P->next;
    }while(P != first);  
}
