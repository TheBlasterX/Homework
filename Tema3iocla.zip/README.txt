user: NOP
pass: IDA_1z_y0ur_fr1end

Din functia login am aflat userul, la if caracterele userului fiind comparate cu N O P in hexa.
Am facut key[i] ^ stored_pass[i] ca sa aflu ce val trebuie sa aiba pass inainte de apelul functiei check_pass.


La fgets , cand imi cere parola, imi trece automat de el (nu ma lasa sa citesc nimic, probabil este o problema ca am len(nume = 4) asa ca am pus in fisierul tema3.c:
	pass[0] = 0x49;
	pass[1] = 0x44; 
	pass[2] = 0x41;
	pass[3] = 0x5f;
	pass[4] = 0x31;
	pass[5] = 0x7a;
	pass[6] = 0x5f;
	pass[7] = 0x79;
	pass[8] = 0x30;
	pass[9] = 0x75;
	pass[10] = 0x72;
	pass[11] = 0x5f;
	pass[12] = 0x66;
	pass[13] = 0x72;
	pass[14] = 0x31;
	pass[15] = 0x65;
	pass[16] = 0x6e;
	pass[17] = 0x64; 
ceea ce reprezinta parola aflata mai sus.

Analiza statica:
	La gets pot face suprascriere pentru a folosi payload-urile.
	Valoarea lui parrot trebuie sa fie in continuare HASHINT*GRUPA pentru a nu declansa alarma.