//331CB Jipa Alexandru-Stefan

	Lucruri realizate in aceasta tema:
	Am generat un drum circular impreuna cu borduri si obstacole.
	Schimb cu ajutorul vertex shader si fragment shader culorile cerului, pamantului, soselei, bordurilor, obstacolelor.
	Masina are acceleratie/decelaratie.
	Pe loc merg rotatiile fata/ lateral ale rotilor.
	Rotatia masinii si a rotilor in timpul deplasarii nu este realista.
	Am implementat doar camera TPS dar nu functioneaza exact.
	Desenarea wireframe si mod solid si proiectiile din perspectica/ ortogonala sunt implementate.
	Coloziunile cu bordurile si obstacolele sunt implementate.
	Coliziunea cu bordura scade 200 de puncte, iar cu obstacolele 50.
	Punctajul creste in functie de distanta parcursa, daca dau cu spatele punctajul scade.
	Am 5 vieti. Cand ajung la 0 programul se opreste.