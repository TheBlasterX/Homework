#include "Laborator5.h"

#include <vector>
#include <string>
#include <iostream>

#include <Core/Engine.h>

using namespace std;

Laborator5::Laborator5()
{
}

Laborator5::~Laborator5()
{
}

void Laborator5::Init()
{
	polygonMode = GL_FILL;
	renderCameraTarget = false;
	TEN = 10;
	hour = 111 * TEN;
	speed = 0;
	angle = 0;
	score = 0;
	lives = 5;
	wheel_ox = 0, wheel_oz = 0;
	x_init = 0, y_init = 0, z_init = 0;
	camera = new Laborator::Camera();
	camera->Set(glm::vec3(0, 2, 3.5f), glm::vec3(0, 1, 0), glm::vec3(0, 1, 0));

	{
		Mesh* mesh = new Mesh("box");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "box.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("sphere");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "sphere.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("plane");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "plane50.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* mesh = new Mesh("Tire");
		mesh->LoadMesh(RESOURCE_PATH::MODELS + "Primitives", "Tire.obj");
		meshes[mesh->GetMeshID()] = mesh;
	}

	{
		Mesh* square1 = Laborator5::CreateSquare("square", glm::vec3(0, 0, 0), 2, glm::vec3(1, 0, 0), true);
		AddMeshToList(square1);
	}

	// Create a shader program for drawing face polygon with the color of the normal
	{
		Shader *shader = new Shader("ShaderLab5");
		shader->AddShader("Source/Laboratoare/Laborator5/Shaders/VertexShader.glsl", GL_VERTEX_SHADER);
		shader->AddShader("Source/Laboratoare/Laborator5/Shaders/FragmentShader.glsl", GL_FRAGMENT_SHADER);
		shader->CreateAndLink();
		shaders[shader->GetName()] = shader;
	}

	projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

}

void Laborator5::FrameStart()
{
	// clears the color buffer (using the previously set color) and depth buffer
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::ivec2 resolution = window->GetResolution();
	// sets the screen area where to draw
	glViewport(0, 0, resolution.x, resolution.y);
}

Mesh* Laborator5::CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill)
{
	glm::vec3 corner = leftBottomCorner;

	std::vector<VertexFormat> vertices =
	{
		VertexFormat(corner, color),
		VertexFormat(corner + glm::vec3(length, 0, 0), color),
		VertexFormat(corner + glm::vec3(length, length, 0), color),
		VertexFormat(corner + glm::vec3(0, length, 0), color)
	};

	Mesh* square = new Mesh(name);
	std::vector<unsigned short> indices = { 0, 1, 2, 3 };

	if (!fill) {
		square->SetDrawMode(GL_LINE_LOOP);
	}
	else {
		// draw 2 triangles. Add the remaining 2 indices
		indices.push_back(0);
		indices.push_back(2);
	}

	square->InitFromData(vertices, indices);
	return square;
}

void Laborator5::collides(float x, float z) {
	int i;
	for (i = 1; i < 18; i += 6) {
		if (z <= -3.25f && z >= -3.75f) {
			if (x >= 1.25f + (float)i && x <= 1.75f + (float)i) {
				score -= 50;
				lives--;
				x_init += 0.5f;
			}
		}
		if (z <= -2.25f && z >= -2.75f) {
			if (x >= 4.25f + (float)i && x <= 4.75f + (float)i) {
				score -= 50;
				lives--;
				x_init += 0.5f;
			}
		}
	}

	for (i = 21; i > -9; i -= 6) {
		if (z <= -11.25f && z >= -11.75f) {
			if (x >= -0.75f + (float)i && x <= -0.25f + (float)i) {
				score -= 50;
				lives--;
				x_init -= 0.5f;
			}
		}
		if (z <= -10.25f && z >= -10.75f) {
			if (x >= -4.75f + (float)i && x <= -4.25f + (float)i) {
				score -= 50;
				lives--;
				x_init -= 0.5f;
			}
		}
	}

	for (i = -8; i < 0; i += 4) {
		if (x <= -8.25f && x >= -8.75f) {
			if (z >= 0.25f + (float)i && z <= 0.75f + (float)i) {
				score -= 50;
				lives--;
				z_init += 0.5f;
			}
		}
		if (x <= -7.25f && x >= -7.75f) {
			if (z >=  3.25f + (float)i && z <= 3.75f + (float)i) {
				score -= 50;
				lives--;
				z_init += 0.5f;
			}
		}
	}

	if (x >= -1 && x <= 1) {
		if (z < -3.75f && z > -4.25f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		} else if (z > 0.25f) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		}
	} else if (z >= -4 && z <= 0) {
		if (x > 1 && z >= -2 && x < 1.25f) {
			score -= 100;
			lives--;
			x_init -= 0.5f;
			return;
		} else if (x < -0.75f && z <= -2 && x > -1.25f) {
			score -= 100;
			lives--;
			x_init += 0.5f;
			return;
		}
	}
	if (x > 1 && x <= 19) {
		if (z < -3.75f && z > -4.25f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		} else if (z > -2.25f) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		}
	} else if (z >= -4 && z <= -2) {
		if (x > 21) {
			score -= 100;
			lives--;
			x_init -= 0.5f;
			return;
		}
	}
	if (x > 19 && x <= 21) {
		if (z > -2.25f) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		} else if (z < -11.75f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		}
	} else if (z <= -4 && z >= -10) {
		if (x < 19.25f && x > 18.75f) {
			score -= 100;
			lives--;
			x_init += 0.5f;
			return;
		} else if (x > 20.75f) {
			score -= 100;
			lives--;
			x_init -= 0.5f;
			return;
		}
	}
	if (z < -10 && z >= -12) {
		if (x > 20.75f) {
			score -= 100;
			lives--;
			x_init -= 0.5f;
			return;
		} else if (x < -8.75f) {
			score -= 100;
			lives--;
			x_init += 0.5f;
			return;
		}
	}
	else if (x <= 19 && x > -7) {
		if (z < -11.75f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		}
		else if (z > -10.25f && z < -9.75f) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		}
	}
	if (x >= -9 && x <= -7) {
		if (z < -11.75f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		} else if (z > -0.25) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		}
	}
	else if (z > -10 && z < -2) {
		if (x > -7.25f && x < -6.75f) {
			score -= 100;
			lives--;
			x_init -= 0.5f;
			return;
		}
		else if (x < -8.75f) {
			score -= 100;
			lives--;
			x_init += 0.5f;
			return;
		}
	}
	if (x > -7 && x < -1) {
		if (z > -0.25) {
			score -= 100;
			lives--;
			z_init -= 0.5f;
			return;
		}
		else if (z < -1.75f && z > -2.25f) {
			score -= 100;
			lives--;
			z_init += 0.5f;
			return;
		}
	}
	else if (z < 0 && z > -2) {
		if (x < -8.75f) {
			score -= 100;
			lives--;
			x_init += 0.5f;
			return;
		}
	}

}

void Laborator5::Update(float deltaTimeSeconds)
{
	int i;

	collides(x_init, z_init);
	
	system("cls");
	printf("LIVES : %d SCORE: %f", lives, score);
	if (lives <= 0) {
		printf("\nGAME OVER");
		exit(0);
	}

	glPolygonMode(GL_FRONT_AND_BACK, polygonMode);

	{	// Render Car
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(x_init, 0.15, z_init)) *
			glm::rotate(modelMatrix, -RADIANS(angle), glm::vec3(0, 1, 0)) *
			glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.5f));
		RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0));  // 255 0 0
	}

	{	// Render wheel top-left
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.18 + x_init, 0.08, -0.2 + z_init));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.001f, 0.001f, 0.001f));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_ox), glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_oz), glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, -RADIANS(angle), glm::vec3(0, 1, 0));
		RenderSimpleMesh(meshes["Tire"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.254, 0.282, 0.294));
	}

	{	// Render wheel top-right
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0.18 + x_init, 0.08, -0.2 + z_init));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.001f, 0.001f, 0.001f));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(180.0f), glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_ox), glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_oz), glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, -RADIANS(angle), glm::vec3(0, 1, 0));
		RenderSimpleMesh(meshes["Tire"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.254, 0.282, 0.294));
	}

	{	// Render wheel bottom-left
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(-0.18 + x_init, 0.08, 0.2 + z_init));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.001f, 0.001f, 0.001f));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_ox), glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, -RADIANS(angle), glm::vec3(0, 1, 0));
		RenderSimpleMesh(meshes["Tire"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.254, 0.282, 0.294));
	}

	{	// Render wheel bottom-right
		glm::mat4 modelMatrix = glm::mat4(1);
		modelMatrix = glm::translate(modelMatrix, glm::vec3(0.18 + x_init, 0.08, 0.2 + z_init));
		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.001f, 0.001f, 0.001f));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(180.0f), glm::vec3(0, 1, 0));
		modelMatrix = glm::rotate(modelMatrix, RADIANS(wheel_ox), glm::vec3(1, 0, 0));
		modelMatrix = glm::rotate(modelMatrix, -RADIANS(angle), glm::vec3(0, 1, 0));
		RenderSimpleMesh(meshes["Tire"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.254, 0.282, 0.294));
	}
	
	if (hour > 110 * TEN && hour <= 160 * TEN) {	//Between 11 a.m. and 4 p.m.
		{	// Render Sky
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.f));
			RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0, 0.749, 1));  // 0 191 255
		}

		// Render ground
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01, 0));
			RenderSimpleMesh(meshes["plane"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.196, 0.803, 0.196));  //50 205 50
		}

		{	// Render road
			for (i = 1; i < 3; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

			for (i = 0; i < 10; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				if (i == 0) {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(1, 0, -4));
				}
				else {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 + 1, 0, -4));
				}
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

			for (i = 3; i < 7; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(19, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

			for (i = 17; i > 3; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 17, 0, -12));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

			for (i = 1; i < 6; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

			for (i = -1; i > -4; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 1, 0, -2));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.878, 0.878, 0.878));
			}

		}

		{
			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(1.12, 0.13, -1));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(11, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(9, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -3));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -9.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(26.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(30.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-4, 0.13, -2.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(6.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-5.0f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(8.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 12.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.88, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 8.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(18.88, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 6));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 10));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.2));
			}
		}

		for (i = 1; i < 18; i += 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 1.5f, 0.26, -3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 4.5f, 0.26, -2.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}
		}

		for (i = 21; i > -9; i -= 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 0.5f, 0.26, -11.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 4.5f, 0.26, -10.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}
		}

		for (i = -8; i < 0; i += 4) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-8.5f, 0.26, i + 0.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-7.5f, 0.26, i + 3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 0, 0.498));
			}
		}

	}
	else if (hour > 160 * TEN && hour <= 190 * TEN || (hour > 70 * TEN && hour <= 110 * TEN)) {	//Between 4 p.m. and 7 p.m. or Between 7 a.m. and 11 a.m.
		{	// Render Sky
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.f));
			RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.160, 0.643, 0.819));  // 41 164 209
		}

		// Render ground
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01, 0));
			RenderSimpleMesh(meshes["plane"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.262, 0.580, 0.262));  // 67 148 67
		}

		{	// Render road
			for (i = 1; i < 3; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}

			for (i = 0; i < 10; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				if (i == 0) {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(1, 0, -4));
				}
				else {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 + 1, 0, -4));
				}
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}

			for (i = 3; i < 7; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(19, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}

			for (i = 17; i > 3; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 17, 0, -12));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}

			for (i = 1; i < 6; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}

			for (i = -1; i > -4; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 1, 0, -2));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.627, 0.627, 0.627));
			}
		}

		{
			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(1.12, 0.13, -1));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(11, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(9, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -3));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -9.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(26.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(30.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-4, 0.13, -2.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(6.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-5.0f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(8.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 12.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.88, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 8.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(18.88, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 6));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 10));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(1, 1, 0.6));
			}
		}

		for (i = 1; i < 18; i += 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 1.5f, 0.26, -3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 4.5f, 0.26, -2.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}
		}

		for (i = 21; i > -9; i -= 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 0.5f, 0.26, -11.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 4.5f, 0.26, -10.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}
		}

		for (i = -8; i < 0; i += 4) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-8.5f, 0.26, i + 0.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-7.5f, 0.26, i + 3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.725, 0.266, 0.494));
			}
		}

	}
	else if (hour > 190 * TEN && hour <= 220 * TEN || (hour > 30 * TEN && hour <= 70 * TEN)) {	//Between 7 p.m. and 10 p.m. or Between 3 a.m. and 7 a.m.
		{	// Render Sky
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.f));
			RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.235, 0.396, 0.458));  // 60 101 117
		}

		// Render ground
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01, 0));
			RenderSimpleMesh(meshes["plane"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.262, 0.380, 0.262));  // 67 97 67
		}

		{	// Render road
			for (i = 1; i < 3; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

			for (i = 0; i < 10; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				if (i == 0) {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(1, 0, -4));
				}
				else {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 + 1, 0, -4));
				}
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

			for (i = 3; i < 7; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(19, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

			for (i = 17; i > 3; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 17, 0, -12));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

			for (i = 1; i < 6; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

			for (i = -1; i > -4; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 1, 0, -2));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.376, 0.376, 0.376));
			}

		}

		{
			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(1.12, 0.13, -1));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(11, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(9, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -3));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -9.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(26.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(30.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-4, 0.13, -2.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(6.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-5.0f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(8.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 12.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.88, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 8.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(18.88, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 6));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 10));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.58, 0.58, 0.266));
			}
		}

		for (i = 1; i < 18; i += 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 1.5f, 0.26, -3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 4.5f, 0.26, -2.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}
		}

		for (i = 21; i > -9; i -= 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 0.5f, 0.26, -11.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 4.5f, 0.26, -10.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}
		}

		for (i = -8; i < 0; i += 4) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-8.5f, 0.26, i + 0.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-7.5f, 0.26, i + 3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.501, 0.266, 0.494));
			}
		}

	}
	else if (hour > 220 * TEN || hour <= 30 * TEN) {	//Between 10 p.m. and 3 a.m.
		{	// Render Sky

			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.f));
			RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.254, 0.282, 0.294));  // 65 72 75
		}

		// Render ground
		{
			glm::mat4 modelMatrix = glm::mat4(1);
			modelMatrix = glm::scale(modelMatrix, glm::vec3(100.0f));
			modelMatrix = glm::translate(modelMatrix, glm::vec3(0, -0.01, 0));
			RenderSimpleMesh(meshes["plane"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.160, 0.188, 0.160));  // 41 48 41
		}

		{	// Render road
			for (i = 1; i < 3; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

			for (i = 0; i < 10; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				if (i == 0) {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(1, 0, -4));
				}
				else {
					modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 + 1, 0, -4));
				}
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

			for (i = 3; i < 7; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(19, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

			for (i = 17; i > 3; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 17, 0, -12));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

			for (i = 1; i < 6; i++) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9, 0, -2 * i));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

			for (i = -1; i > -4; i--) {
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i * 2 - 1, 0, -2));
				modelMatrix = glm::rotate(modelMatrix, RADIANS(90.0f), glm::vec3(1, 0, 0));
				RenderSimpleMesh(meshes["square"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.125, 0.125, 0.125));
			}

		}

		{
			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(1.12, 0.13, -1));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(11, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(9, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(20.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -4.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-1.12, 0.13, -3));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 2.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -9.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(26.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(6, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(30.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-4, 0.13, -2.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(6.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-5.0f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(8.0f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 12.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-6.88, 0.13, -6));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 8.0f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(18.88, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 6));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12, 0.13, -7));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 10));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -1.88));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(21.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, 0.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}

			{	// Render border
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-9.12f, 0.13, -12.12));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.25f, 0.25f, 0.25f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.419, 0.419, 0.247));
			}
		}

		for (i = 1; i < 18; i += 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 1.5f, 0.26, -3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i + 4.5f, 0.26, -2.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}
		}

		for (i = 21; i > -9; i -= 6) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 0.5f, 0.26, -11.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(i - 4.5f, 0.26, -10.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}
		}

		for (i = -8; i < 0; i += 4) {
			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-8.5f, 0.26, i + 0.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}

			{	// Render Obstacle
				glm::mat4 modelMatrix = glm::mat4(1);
				modelMatrix = glm::translate(modelMatrix, glm::vec3(-7.5f, 0.26, i + 3.5f));
				modelMatrix = glm::scale(modelMatrix, glm::vec3(0.5f, 0.5f, 0.5f));
				RenderSimpleMesh(meshes["box"], shaders["ShaderLab5"], modelMatrix, glm::vec3(0.294, 0.203, 0.250));
			}
		}

	}

	hour++;

	if (hour == 240 * TEN) {
		hour = 0;
	}

	 //Render the camera target. Useful for understanding where is the rotation point in Third-person camera movement
//	if (renderCameraTarget)
//	{
//		glm::mat4 modelMatrix = glm::mat4(1);
//		modelMatrix = glm::translate(modelMatrix, camera->GetTargetPosition());
//		modelMatrix = glm::scale(modelMatrix, glm::vec3(0.1f));
//		RenderMesh(meshes["sphere"], shaders["VertexNormal"], modelMatrix);
//	}

	if (per) projectionMatrix = glm::perspective(fov, 3.0f, 0.1f, 100.0f);

	if (ort) projectionMatrix = glm::ortho(x, y, z, t, 0.1f, 100.0f);

	if (per == 0 && ort == 0) projectionMatrix = glm::perspective(RADIANS(60), window->props.aspectRatio, 0.01f, 200.0f);

}

void Laborator5::FrameEnd()
{
	DrawCoordinatSystem(camera->GetViewMatrix(), projectionMatrix);
}

void Laborator5::RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 & modelMatrix, const glm::vec3 &color)
{
	if (!mesh || !shader || !shader->GetProgramID())
		return;

	int location;

	// render an object using the specified shader and the specified position
	glUseProgram(shader->program);

	location = glGetUniformLocation(shader->GetProgramID(), "object_color");
	glUniform3fv(location, 1, glm::value_ptr(color));

	// Bind model matrix
	GLint loc_model_matrix = glGetUniformLocation(shader->program, "Model");
	glUniformMatrix4fv(loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

void Laborator5::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix)
{
	if (!mesh || !shader || !shader->program)
		return;

	// render an object using the specified shader and the specified position
	shader->Use();
	glUniformMatrix4fv(shader->loc_view_matrix, 1, GL_FALSE, glm::value_ptr(camera->GetViewMatrix()));
	glUniformMatrix4fv(shader->loc_projection_matrix, 1, GL_FALSE, glm::value_ptr(projectionMatrix));
	glUniformMatrix4fv(shader->loc_model_matrix, 1, GL_FALSE, glm::value_ptr(modelMatrix));

	mesh->Render();
}

// Documentation for the input functions can be found in: "/Source/Core/Window/InputController.h" or
// https://github.com/UPB-Graphics/Framework-EGC/blob/master/Source/Core/Window/InputController.h

void Laborator5::OnInputUpdate(float deltaTime, int mods)
{
	// move the camera only if MOUSE_RIGHT button is pressed
	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float cameraSpeed = 2.0f;

		if (window->KeyHold(GLFW_KEY_W)) {
			// TODO : translate the camera forward
			camera->TranslateForward(cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_A)) {
			// TODO : translate the camera to the left
			camera->TranslateRight(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_S)) {
			// TODO : translate the camera backwards
			camera->TranslateForward(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_D)) {
			// TODO : translate the camera to the right
			camera->TranslateRight(cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_Q)) {
			// TODO : translate the camera down
			camera->TranslateUpword(-cameraSpeed * deltaTime);
		}

		if (window->KeyHold(GLFW_KEY_E)) {
			// TODO : translate the camera up
			camera->TranslateUpword(cameraSpeed * deltaTime);
		}
	}

	if (window->KeyHold(GLFW_KEY_UP)) {
		// TODO : translate the camera forward
		wheel_ox += 5.0f;
		//speed += 0.01f;
		if (angle <= 45 && angle >= -45) {
			z_init -= 0.05f;
			speed = z_init;
			score += fabs(z_init);
		} else if (angle < -45 && angle >= -120) {
			x_init -= 0.05f;
			speed = x_init;
			score += fabs(x_init);
		} else if (angle >= 45 && angle <= 135) {
			x_init += 0.05f;
			speed = x_init;
			score += fabs(x_init);
		} else if ((angle >= 135 && angle <= 180) || (angle <= -135 && angle >= -225)) {
			z_init += 0.05f;
			speed = z_init;
			score += fabs(z_init);
		}
		camera->TranslateForward(-speed * deltaTime / 100);
	}



	if (window->KeyHold(GLFW_KEY_DOWN)) {
		// TODO : translate the camera backwards
		wheel_ox -= 5.0f;
		speed -= 0.01f;
		if (angle <= 45 && angle >= -45) {
			z_init += 0.05f;
			speed = z_init;
			score -= fabs(z_init);
		}
		else if (angle < -45 && angle >= -120) {
			x_init += 0.05f;
			speed = x_init;
			score -= fabs(x_init);
		}
		else if (angle >= 45 && angle <= 135) {
			x_init -= 0.05f;
			speed = x_init;
			score -= fabs(x_init);
		}
		else if ((angle >= 135 && angle <= 180) || (angle <= -135 && angle >= -225)) {
			z_init -= 0.05f;
			speed = z_init;
			score -= fabs(z_init);
		}

		camera->TranslateForward(speed * deltaTime / 100);
	}


}

void Laborator5::OnKeyPress(int key, int mods)
{

	if (window->KeyHold(GLFW_KEY_RIGHT)) {
		// TODO : translate the camera to the right
		if (wheel_oz > -50.0f)
			wheel_oz -= 5.0f;
		if (speed != 0) {
			angle += 5.0f;
			x_init += 0.1f;
			speed = x_init;
		}
		camera->TranslateRight(speed / 25);
	}

	if (window->KeyHold(GLFW_KEY_LEFT)) {
		// TODO : translate the camera to the left
		//camera->TranslateRight(-speed * deltaTime);
		if (wheel_oz < 50.0f)
			wheel_oz += 5.0f;
		if (speed != 0) {
			angle -= 5.0f;
			x_init -= 0.1f;
			speed = x_init;
		}
		camera->TranslateRight(-speed / 25);
	}

	// add key press event
	if (key == GLFW_KEY_T)
	{
		renderCameraTarget = !renderCameraTarget;
	}

	if (key == GLFW_KEY_O)
	{
		ort = true;
		per = false;
	}

	if (key == GLFW_KEY_P)
	{
		per = true;
		ort = false;
	}

	if (key == GLFW_KEY_I)
	{
		per = false;
		ort = false;
	}

	if (key == GLFW_KEY_SPACE)
	{
		switch (polygonMode)
		{
		case GL_POINT:
			polygonMode = GL_FILL;
			break;
		case GL_LINE:
			polygonMode = GL_POINT;
			break;
		default:
			polygonMode = GL_LINE;
			break;
		}
	}

}

void Laborator5::OnKeyRelease(int key, int mods)
{
	// add key release event
}

void Laborator5::OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY)
{
	// add mouse move event

	if (window->MouseHold(GLFW_MOUSE_BUTTON_RIGHT))
	{
		float sensivityOX = 0.001f;
		float sensivityOY = 0.001f;

		if (window->GetSpecialKeyState() == 0) {
			renderCameraTarget = false;
			// TODO : rotate the camera in First-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateFirstPerson_OX(deltaX * sensivityOX);
			camera->RotateFirstPerson_OY(deltaY * sensivityOY);
		}

		if (window->GetSpecialKeyState() && GLFW_MOD_CONTROL) {
			renderCameraTarget = true;
			// TODO : rotate the camera in Third-person mode around OX and OY using deltaX and deltaY
			// use the sensitivity variables for setting up the rotation speed
			camera->RotateThirdPerson_OX(-deltaX*sensivityOX);
			camera->RotateThirdPerson_OY(-deltaY*sensivityOY);
		}

	}
}

void Laborator5::OnMouseBtnPress(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button press event
}

void Laborator5::OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods)
{
	// add mouse button release event
}

void Laborator5::OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY)
{
}

void Laborator5::OnWindowResize(int width, int height)
{
}
