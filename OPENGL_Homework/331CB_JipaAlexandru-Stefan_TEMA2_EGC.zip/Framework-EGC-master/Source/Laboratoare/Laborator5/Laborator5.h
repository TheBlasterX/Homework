#pragma once
#include <Component/SimpleScene.h>
#include "LabCamera.h"
#include <Component/Transform/Transform.h>
#include <Core/GPU/Mesh.h>

class Laborator5 : public SimpleScene
{
public:
	Laborator5();
	~Laborator5();

	void Init() override;

private:
	void FrameStart() override;
	void Update(float deltaTimeSeconds) override;
	void FrameEnd() override;

	void Laborator5::RenderMesh(Mesh * mesh, Shader * shader, const glm::mat4 & modelMatrix) override;
	void RenderSimpleMesh(Mesh *mesh, Shader *shader, const glm::mat4 &modelMatrix, const glm::vec3 &color = glm::vec3(1));
	Mesh* CreateSquare(std::string name, glm::vec3 leftBottomCorner, float length, glm::vec3 color, bool fill = false);
	void collides(float x, float z);

	void OnInputUpdate(float deltaTime, int mods) override;
	void OnKeyPress(int key, int mods) override;
	void OnKeyRelease(int key, int mods) override;
	void OnMouseMove(int mouseX, int mouseY, int deltaX, int deltaY) override;
	void OnMouseBtnPress(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseBtnRelease(int mouseX, int mouseY, int button, int mods) override;
	void OnMouseScroll(int mouseX, int mouseY, int offsetX, int offsetY) override;
	void OnWindowResize(int width, int height) override;

protected:
	GLenum polygonMode;
	Laborator::Camera *camera;
	glm::mat4 projectionMatrix;
	bool renderCameraTarget;
	float fov = 1.0f;
	bool per = false;
	bool ort;
	float x = -5.0f, y = 5.0f, z = -5.0f, t = 5.0f;
	float speed, angle;
	float x_init, y_init, z_init;
	int lives;
	float score;
	float wheel_ox, wheel_oz;
	int TEN;
	int hour;
};
