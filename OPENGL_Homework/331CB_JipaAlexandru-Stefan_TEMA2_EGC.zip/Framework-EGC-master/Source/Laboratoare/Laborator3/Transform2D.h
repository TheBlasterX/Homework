#pragma once

#include <include/glm.h>

namespace Transform2D
{
	// Translate matrix
	inline glm::mat3 Translate(float translateX, float translateY)
	{
		// TODO implement translate matrix

		return glm::transpose(glm::mat3(1.0f, 0.0f, translateX,
			0.0f, 1.0f, translateY,
			0.0f, 0.0f, 1.0f));
	}

	// Scale matrix
	inline glm::mat3 Scale(float scaleX, float scaleY)
	{
		// TODO implement scale matrix
		return glm::transpose(glm::mat3(scaleX, 0.0f, 0.0f,
			0.0f, scaleY, 0.0f,
			0.0f, 0.0f, 1.0f));
	}

	// Rotate matrix
	inline glm::mat3 Rotate(float radians)
	{
		// TODO implement rotate matrix
		float cosR = glm::cos(radians);
		float sinR = glm::sin(radians);
		return glm::transpose(glm::mat3(cosR, -sinR, 0.0f,
			sinR, cosR, 0.0f,
			0.0f, 0.0f, 1.0f));
	}
}
