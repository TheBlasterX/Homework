#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

#define len 1000

int main()
{
	FILE * text;
	text = fopen("tm.in", "r");
	int n;	//nr de stari ale MTD
	fscanf(text, "%d", &n);

	char stari[n][8];	//starile MTD

	long i;

	for(i = 0; i < n; i++)
		fscanf(text, "%s", stari[i]);

	int m;	//nr de stari finale ale MTD
	fscanf(text, "%d", &m);

	char stari_finale[m][8];	//starile finale
	for(i = 0; i < m; i++)
		fscanf(text, "%s", stari_finale[i]);	

	char S0[8];	//starea initiala
	fscanf(text, "%s", S0);

	long p;
	fscanf(text, "%ld", &p);	//nr de tranzitii

	char stari_crt[p][8];
	char alfabet[p][2];
	char stari_urm[p][8];
	char directie[p];

	for(i = 0; i < p; i++){
		fscanf(text, "%s", stari_crt[i]);	// starea curenta
		fscanf(text, "%s", &alfabet[i][0]);		//caracterul crt de pe banda
		fscanf(text, "%s", stari_urm[i]);	// starea urmatoare
		fscanf(text, "%s", &alfabet[i][1]);	//caract. de scris pe banda
		fscanf(text, "%s", &directie[i]);	// pozitia pe banda(L R H)
	}

	FILE * tapein = fopen("tape.in", "r");
	char tape[len];	//len = 1000
	fscanf(tapein, "%s", tape);
	int lenbanda = strlen(tape);
	int pos = 1;
	int j;
	//Pun # pe banda in caz ca ajung sa citesc caracter vid(!= #)
	for(i = lenbanda; i < len; i++)
		tape[i] = '#';		

	FILE * write = fopen("tape.out", "w");

start://fac verificarea in afara forului de parcurge pt a face mai putine parcurgeri
	for(j = 0; j < m; j++){
		if(!strcmp(S0, stari_finale[j])){			
			fprintf(write, "%s", tape);				
			return 0;	//Verific daca am ajungs in una dintre starile finale				
			}
	}

	for(i = 0; i <= p ; i++){	//parcurg tranzitii

		if (i == p){
			fprintf(write, "Se agata!");
			return 0;
		}
		//S0 este stare init, dar actualizez starea in S0
		if(!strcmp(S0, stari_crt[i])){

			if(tape[pos] == alfabet[i][0]){

				strcpy(S0, stari_urm[i]);
				tape[pos] = alfabet[i][1];
				//actualizez banda	
				if (directie[i] == 'L'){
					pos--;
				}
					
				if(directie[i] == 'R'){
					pos++;
				}
				goto start;
			}
		}
	}

	fclose(text);
	fclose(tapein);
	fclose(write);

	return 0;
}