function q = hsvHistogram(I,count_bins)
	
	a = double(imread(I));
	r = a(:,:,1);
	g = a(:,:,2);
	b = a(:,:,3);
	[n m] = size(r);
	H = zeros(1,count_bins);
	S = zeros(1,count_bins);
	V = zeros(1,count_bins);
	h = zeros(n,m);
	s = zeros(n,m);
	v = zeros(n,m);
	
	for i = 1 : n
		for j = 1 : m
			r1 = r(i,j) / 255;
			g1 = g(i,j) / 255;
			b1 = b(i,j) / 255;
			cmax = max(r1, max(g1, b1));
			cmin = min(r1, min(g1, b1));
			delta = cmax - cmin;
			if delta == 0
					h(i,j) = 0;
			else
				if cmax == r1 
					h(i,j) = 60 * mod(((g1 - b1) / delta), 6);
				endif 
				if cmax == g1 
					h(i,j) = 60 * (((b1 - r1) / delta) + 2);
				endif
				if cmax == b1 
					h(i,j) = 60 * (((r1 - g1) / delta) + 4);
				endif
			endif
			h(i,j) = h(i,j) / 360;
			if cmax == 0
				s(i,j) = 0;
			else	
				s(i,j) = delta / cmax;
			endif
			v(i,j) = cmax;

			x = h(i,j);
			index = fix(x * count_bins * 100 / 101);	%inmultesc valorile lui h/s/v cu count_bins ca sa le aduc din [0;1] in [0;count_bins]			
			H(index + 1)++;   %index + 1 in caz ca indexul este 0, fiindca nu exista pozitia 0 in vector
			x = s(i,j);
			index = fix(x * count_bins * 100 / 101 );
			S(index + 1)++;
			x = v(i,j);
			index = fix(x * count_bins * 100 / 101);
			V(index + 1)++;
		endfor
	endfor
	q = [H S V];
endfunction