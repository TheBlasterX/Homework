function v = rgbHistogram(I,count_bins)
	a = double(imread(I));
	r = a(:,:,1);
	g = a(:,:,2);
	b = a(:,:,3);
	%dimensiunile matricei a : r , g si b
	[n m] = size(r);
	%dimensiunile un unei matrice de forma r , g si b (fiind aceeasi la toate 3)
	%3 vectori pentru construirea histogramei
	R = zeros(1,count_bins);
	G = zeros(1,count_bins);
	B = zeros(1,count_bins);

	%index este parte intreaga din valoarea pixelului inmultita cu count_bins si impartit totul la 256
	%formula am dedus-o din relatia din pdf
	%am pus index + 1 pentru ca indexul poate fi zero , dar nu exista pozitia zero in octave
	for i = 1 : n
		for j = 1 : m
			x = r(i,j);
			index = fix(x * count_bins / 256);

				R(index + 1)++;

			x = g(i,j);

			index = fix(x * count_bins / 256);
				G(index + 1)++;

			x = b(i,j);

			index = fix(x * count_bins / 256);
				B(index + 1)++;

		endfor
	endfor
	v = [R G B];	%concatenarea celor 3 vectori R G B

endfunction