//Jipa Alexandru-Stefan 321CB
Aceasta tema are scopul a gasi o transformare care sa reduca in timp polinomial k vertex-cover la sat.
Tema este facuta in java (java 8). Am folosit 4 clase in realizarea acestei teme.

Clasa Tema4 contine metoda main si nu face decat sa apeleze metoda de citire din clasa Read.

Clasa Read face citirea fisierului "test.in".
nodes_number = numar de noduri
edges_number = numar de muchii
nodes_cover = numar de noduri care formeaza acoperirea
vector_edges[edges_number][2] = contine fiecare muchie salvata ca string si fiecare nod poate fi selectat mai usor.
Trimite ca paramatrii nodes_number, edges_number, nodes_cover, vector_edges metodei Transform din clasa Transformation.

Clasa Transformation contine metoda Transform care realizeaza transformarea lui k vertex-cover la sat.
Folosesc string-ul clauses pentru a tine clauzele si apoi le concatenez la CNF, care reprezinta formula booleana primita de sat.
Constructia CNF-ului se realizeaza astfel:
Folosesc k * n numar variabile in formula CNF, toate avand cate 2 indici(k = nr noduri acoperie, n = nr noduri ale grafului).
Mai intai, pentru fiecare muchie creez cate o clauza care are doar literali pozitivi(fara negatie), fiecare literal avand urmatoarea forma:
Primul indice este de la 1 la k, iar al doilea indice poate fi doar unul dintre nodurile care sunt unite de muchie.
Toate aceste clauze sunt concatentate cu "^" in CNF;
Apoi, la aceasta grupare de clauze concatenez o noua grupare de clauze formata astfel:
Creez k clauze, fiecare avand exact 2 literali care sunt si negativi(cu negatie).Literalii sunt formati astfel:
Primul indice poate avea valori cuprinse intre 1 si k inclusiv.
Pentru fiecare clauza de acest tip:
	Primul literal are mereu cel de-al 2-lea indice mai mic decat cel de-al 2-lea indice al celui de-al 2-lea literal.
Apoi formula formata este trimis unei metode de scriere din clasa de scriere.

Clasa Write are metoda Write(String CNF) care realizeaza scrierea in fisierul "test.out" a formulei CNF.