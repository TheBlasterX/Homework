/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 *
 * @author Stefan Jipa
 */
public class Write {

    public Write() {
    }

    //metoda de scriere in fisier
    public Write(String CNF) throws FileNotFoundException {
        PrintWriter write_cnf = new PrintWriter("test.out");
        write_cnf.print(CNF);       //scriu cnf in fisier
        write_cnf.close();
    }
}
