/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Stefan Jipa
 */
public class Read {

    //citirea fisierului
    public void StartReading() throws FileNotFoundException, IOException {
        Scanner ReadFile = new Scanner(new File("test.in"));
        int nodes_number = ReadFile.nextInt();      //numar noduri
        int edges_number = ReadFile.nextInt();      //numar muchii
        int nodes_cover = ReadFile.nextInt();       //numar noduri din acoperirea grafului
        int i, j;
        int v1, v2;
        String vector_edges[][] = new String[edges_number][2];  //matrice in care salvez muchiile ca stringuri
        //literalii vor avea 2 indici
        for (i = 1; i <= edges_number; i++) {
            v1 = ReadFile.nextInt();
            v2 = ReadFile.nextInt();
            vector_edges[i - 1][0] = "" + v1;
            vector_edges[i - 1][1] = "" + v2;
        }

        ReadFile.close();
        Transformation t = new Transformation();

        t.Transform(nodes_number, edges_number, nodes_cover, vector_edges);     //apelez metoda de transformare
    }
}
