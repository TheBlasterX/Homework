/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileNotFoundException;

/**
 *
 * @author Stefan Jipa
 */
public class Transformation {

    public Transformation() {
    }

    public void Transform(int nodes_number, int edges_number, int nodes_cover, String[][] vector_edges) throws FileNotFoundException {
        int i, j, count;
        String clauses;       //clauze cu ajutorul carora construiesc CNF
        String CNF = "";      //Formula booleana pe care o construiesc
        int val1, val2;
        clauses = "";
        //Pt fiecare muchie creez cate o clauza, in care pentru fiecare literal
        //primul indice este de la 1 la nodes_cover(acoperirea)
        //iar cel de-al doilea indice poate fi doar unul dintre nodurile conectate de muchie

        for (i = 0; i < edges_number; i++) {
            val1 = Integer.parseInt(vector_edges[i][0]);
            val2 = Integer.parseInt(vector_edges[i][1]);
            CNF += "(";
            for (j = 1; j <= nodes_cover; j++) {
                clauses += "x" + j + val1;
                clauses += "Vx" + j + val2;
                if (j != nodes_cover) {
                    clauses += "V";
                }
            }
            CNF += clauses;
            CNF += ")";
            if (i != edges_number - 1) {
                CNF += "^";
            }
            clauses = "";
        }

        CNF += "^";

//construiesc nodes_cover(acoperiea) clauze cu cate 2 literali, fiecare cu negatie
//fiecare literal va avea primul indice de la 1 la nodes_cover
//noduri, iar al doilea indice al primului literal dintr-o clauza va avea primul indice mai mic decat
//cel de-al 2-lea indice al celui de-al 2-lea literal al aceleiasi clauze
        for (j = 1; j <= nodes_cover; j++) {
            i = 1;
            while (i < nodes_number) {
                for (count = i + 1; count <= nodes_number; count++) {
                    if (j == nodes_cover && count == nodes_number && i == nodes_number - 1) {
                        clauses = "~x" + j + i;
                        clauses += "V~x" + j + count;
                        CNF += "(";
                        CNF += clauses;
                        CNF += ")";
                    } else {
                        clauses = "~x" + j + i;
                        clauses += "V~x" + j + count;
                        CNF += "(";
                        CNF += clauses;
                        CNF += ")" + "^";
                    }
                }
                i++;
            }
        }

        Write toWrite = new Write(CNF);
    }
}