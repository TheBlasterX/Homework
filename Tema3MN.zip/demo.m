function demo
T=[cos(45*pi/180) sin(45*pi/180); -sin(45*pi/180) cos(45*pi/180)]
forward_mapping('flapping_duck.png', T);
T=[cos(90*pi/180) sin(90*pi/180); -sin(90*pi/180) cos(90*pi/180)]
forward_mapping('flapping_duck.png', T);
T=[cos(180*pi/180) sin(180*pi/180); -sin(180*pi/180) cos(180*pi/180)]
forward_mapping('flapping_duck.png', T);
T=[cos(45*pi/180) sin(45*pi/180); -sin(45*pi/180) cos(45*pi/180)]
forward_mapping('flapping_bird.png', T);
T=[cos(90*pi/180) sin(90*pi/180); -sin(90*pi/180) cos(90*pi/180)]
forward_mapping('flapping_bird.png', T);
T=[cos(180*pi/180) sin(180*pi/180); -sin(180*pi/180) cos(180*pi/180)]
forward_mapping('flapping_bird.png', T);
endfunction
