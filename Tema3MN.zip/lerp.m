function value = lerp(v, x)
    [n m] = size(v);	
    if x < n || x > m	%verifica daca x este in afara domeniului	
    	value = 0;		%in acest caz functia va intoarce 0
    else
    		if x == m		%in caz ca x este ultima pozitie din vector
    			y = x - 1;
    		else
    			y = fix(x);	%in restul cazurilor
    		endif	
    		value = v(y) + (v(y + 1) - v(y)) / (y + 1 - y) * (x - y); 
    endif		
end