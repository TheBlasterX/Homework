function img_out = forward_mapping(img_in, T)
	image = imread(img_in);
	[n m] = size(image);
	%Calculeaz paddingul imaginii
	%(in caz ca imaginea are nevoie de dimensiuni mai mari)
	Diag = sqrt(n ^ 2 + m ^ 2);
	RowPad = ceil(Diag - n) + 2;
	ColPad = ceil(Diag - m) + 2;
	imagepad = zeros(n + RowPad, m + ColPad);
	imagepad(ceil(RowPad / 2) : (ceil(RowPad / 2) + n - 1), ceil(ColPad / 2) : (ceil(ColPad / 2) + m - 1)) = image;
	
	%midpoints
	midx = ceil((size(imagepad, 1) + 1) / 2);
	midy = ceil((size(imagepad, 2) + 1) / 2);

	img_out = zeros(size(imagepad));%dimens imaginii output

	[row col] = size(img_out);

	for i = 1 : row
		for j = 1 : col
			x = (i - midx) * T(1, 1) + (j - midy) * T(1, 2);
			y = (i - midx) * T(2, 1) + (j - midy) * T(2, 2);
			x = round(x) + midx;
			y = round(y) + midy;
			if x > 0 && y > 0 && x <= col && y <= row
				img_out(i, j) = imagepad(x, y); %crearea noii imagini
			endif
		endfor
	endfor
	imwrite(mat2gray(img_out), 'file.png'); %sintaxa din pdf
endfunction				