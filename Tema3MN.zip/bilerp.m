function value = bilerp(img, row, col)
    [n m] = size(img);
    r = zeros(1, m);
    for i = 1 : n
    	r(i) = lerp((img(i, :)), row); %inerpolez pe axa ox fiecare linie 
    endfor	
    value = lerp(r, col);   %la final interpolez vectorul obtinut mai sus
end