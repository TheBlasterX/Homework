/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author Stefan Jipa
 * Versiunea sau iteratia 2
 * Implementata cu vector
 */
public class Version2 {

    ArrayList list = new ArrayList();

    public void add(Nodes nod) {
        list.add(nod);
    }

    public void del(Nodes nod) {
        list.remove(nod);
    }

}
