/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Stefan Jipa
 * 
 * Aici fac citirea din fisier si apelez functiile de executat asupra grafului
 * Am ales sa fac statici get-erii pt settings pt a le putea accesa mai usor in alte clase
 */
public class Read {

    private static int setA;    //setare pt nod A
    private static int setB;    //setare pt nod B
    private static int setC;    //setare pt nod C

    public static int getSetA() {
        return setA;
    }

    public static int getSetB() {
        return setB;
    }

    public static int getSetC() {
        return setC;
    }

    public void StartReading(String input) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(input));

        String line = null;
        StringBuilder stringBuilder = new StringBuilder();
        String ls = System.getProperty("line.separator");
        Graf graf = new Graf();

        try {
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(" ");
                if (parts[0].equals("Settings")) {
                    setA = Integer.parseInt(parts[1]);
                    setB = Integer.parseInt(parts[2]);
                    setC = Integer.parseInt(parts[3]);
                }
                if (parts[0].equals("Add")) {
                    String nod_type = parts[1];
                    String nod_to_add = parts[2];
                    int adiac_nodes = parts.length - 3;
                    String nodes_adiac[] = null;
                    for (int i = 3; i < adiac_nodes; i++) {
                        nodes_adiac[i] = parts[i];
                    }

                    graf.add(nod_type, nod_to_add, nodes_adiac);
                }

                if (parts[0].equals("Del")) {
                    String nod_type = parts[1];
                    String nod_to_del = parts[2];
                    graf.Del(nod_type, nod_to_del);
                    //Del()..
                }

                if (parts[0].equals("AddM")) {
                    String nod1 = parts[1];
                    String nod2 = parts[2];
                    //AddM()..
                    graf.addM(nod1, nod2);
                }

                if (parts[0].equals("DelM")) {
                    String nod1 = parts[1];
                    String nod2 = parts[2];
                    graf.DelM(nod1, nod2);
                    //DelM()..
                }

            }

        } finally {
            reader.close();
        }
    }
}
