/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author Stefan Jipa
 * Structura grafului este implementata printr-un arraylist cu elemente de tip Nodes
 * Care pot fi de tip NodA, NodB, NodC
 */
public class Graf {

    ArrayList<Nodes> list = new ArrayList();
    static int id = 0;

    /**
     * 
     * @param nod_type
     * @param nod_to_add
     * @param nodes_adiac
     * Primesc ca parametru tipul nodului, numele nodului si nodurile lui adiacente
     * Pentru fiecare apelez functia de aduagare din NodA, NodB sau NodC
     * Si creez muchii intre nodul adaugat si nodurile lui adiacente
     */
    public void add(String nod_type, String nod_to_add, String[] nodes_adiac) {
        Graf.id++;
        if (nod_type.equals("NodA")) {

            NodA Nod_add = new NodA(nod_to_add, Graf.id);
            list.add(Nod_add);
            for (int i = 0; i < nodes_adiac.length; i++) {
                for (Nodes num : list) {

                    if (num.getName().equals(nodes_adiac[i])) {
                        num.addM(Nod_add);
                        Nod_add.addM(num);
                    }
                }
            }

        }

        if (nod_type.equals("NodB")) {

            NodB Nod_add = new NodB(nod_to_add, Graf.id);
            list.add(Nod_add);
            for (int i = 0; i < nodes_adiac.length; i++) {
                for (Nodes num : list) {

                    if (num.getName().equals(nodes_adiac[i])) {
                        num.addM(Nod_add);
                        Nod_add.addM(num);
                    }
                }
            }

        }

        if (nod_type.equals("NodC")) {

            NodC Nod_add = new NodC(nod_to_add, Graf.id);
            list.add(Nod_add);
            for (int i = 0; i < nodes_adiac.length; i++) {
                for (Nodes num : list) {

                    if (num.getName().equals(nodes_adiac[i])) {
                        num.addM(Nod_add);
                        Nod_add.addM(num);
                    }
                }
            }
        }

    }
    
    /**
     * 
     * @param nod1
     * @param nod2
     *Similar cu adaugarea de nod, doar ca adaug muchii, deci am de facut 2 inserari de nod
     * Il adaug pe fiecare in lista de adiacenta a celuilalt
     */
    
    public void addM(String nod1, String nod2) {
        for (Nodes contor1 : list) {
            if (contor1.getName().equals(nod1)) {
                for (Nodes contor2 : list) {
                    if (contor2.getName().equals(nod2)) {
                        if (contor1 instanceof NodA) {

                            NodA Nod_1 = new NodA(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                        }

                        if (contor1 instanceof NodB) {

                            NodB Nod_1 = new NodB(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                        }

                        if (contor1 instanceof NodC) {

                            NodC Nod_1 = new NodC(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.addM(Nod_2);
                                Nod_2.addM(Nod_1);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * 
     * @param nod_type
     * @param nod_to_del
     * Sterg nod din graf
     */
    
    public void Del(String nod_type, String nod_to_del){
        for(Nodes contor : list){
            if(contor.getName().equals(nod_to_del)){
                list.remove(contor);
                break;
            }
        }
    }
    
    /**
     * 
     * @param nod1
     * @param nod2
     * Sterg o muchie
     * Similar cu stergerea din graf
     * Scot fiecare nod din lista de adiacenta a celuilalt nod
     */
    public void DelM(String nod1, String nod2){
      for (Nodes contor1 : list) {
            if (contor1.getName().equals(nod1)) {
                for (Nodes contor2 : list) {
                    if (contor2.getName().equals(nod2)) {
                        if (contor1 instanceof NodA) {

                            NodA Nod_1 = new NodA(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                        }

                        if (contor1 instanceof NodB) {

                            NodB Nod_1 = new NodB(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                        }

                        if (contor1 instanceof NodC) {

                            NodC Nod_1 = new NodC(nod1, contor1.getId());

                            if (contor2 instanceof NodA) {
                                NodA Nod_2 = new NodA(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodB) {
                                NodB Nod_2 = new NodB(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }

                            if (contor2 instanceof NodC) {
                                NodC Nod_2 = new NodC(nod2, contor2.getId());
                                Nod_1.DelM(Nod_2);
                                Nod_2.DelM(Nod_1);
                            }
                        }
                    }
                }
            }
        }  
    }
    
}
