//Jipa Alexandru-Stefan 321CB

In aceasta tema am folosit 10 clase.

In clasa Tema2 se afla metoda main.
Clasa Read care realizeaza citirea din fisier si apeleaza functiile de executat asupra grafului.
In clasa Graf sunt implementarea grafului si operatiile ce se pot executa asupra lui.
In clasa Nodes sunt metode supra-scrise in clasele NodA, NodB, NodC.
Folosesc 3 clase NodA, NodB, NodC pentru a reprezenta cele 3 tipuri de noduri ale grafului.
Folosesc 3 clase Folosesc 3 clase Version1, Version2, Version3 pentru a implementa cele 3 tipuri de mentinere ale nodurilor adiacente.