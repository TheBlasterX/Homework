/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Stefan Jipa
 * Clasa cuprinde atributele unui nod de tip B si operatiile de executat pe acesta
 * In functie de ce versiune are nodul apelez functia lui specifica de inserare nod/muchie, stergere nod/muchie
 */
public class NodB extends Nodes{

    String name;
    int id;
    int iteration;
    Version1 v1;
    Version2 v2;
    Version3 v3;
    
    public NodB() {

    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getId() {
        return id;
    }

    public NodB(String name, int id) {
        this.name = name;
        this.id = id;
        this.iteration = Read.getSetB();
        if (this.iteration == 1) {
            v1 = new Version1();
        }
        if (this.iteration == 2) {
            v2 = new Version2();
        }
        if (this.iteration == 3) {
            v3 = new Version3();
        }
    }
    
    @Override
    public void addM(Nodes nod) {
        this.iteration = Read.getSetB();
        if (this.iteration == 1) {
            v1.add(nod);
        }
        if (this.iteration == 2) {
            v2.add(nod);
        }
        if (this.iteration == 3) {
            v3.add(nod);
        }
    }
    
    @Override
    public void DelM(Nodes nod){
       this.iteration = Read.getSetB();
        if (this.iteration == 1) {
            v1.del(nod);
        }
        if (this.iteration == 2) {
            v2.del(nod);
        }
        if (this.iteration == 3) {
            v3.del(nod);
        } 
    }

    @Override
    public int getIteration() {
        return iteration;
    }
    
}