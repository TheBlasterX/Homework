#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){

	int n, m, i, k, op;
	scanf("%d",&n);
	getchar();
	char **p = (char**)malloc(sizeof(char*)*n);
	for(i = 0; i < n; i++)
	{
		p[i]=(char*)malloc(sizeof(char)*1000); 		
		fgets(p[i],1000,stdin);
		
	}			
	scanf("%d",&m);
	getchar();
	for(i = 0; i < m; i++)
 	{	
		scanf("%d",&op);
		getchar();
		switch(op)
		{
			case 1:	
				{
				int nr, j;
				nr = 0;
				char *cuvant = (char*)malloc(sizeof(char)*100);
				scanf("%s",cuvant);
				getchar();
				char **p_aux = (char**)malloc(sizeof(char*)*n);
				for(j = 0; j < n; j++)
				{
					p_aux[j] = (char*)malloc(sizeof(char)*1000);
					strcpy(p_aux[j], p[j]);
					char *caut = strtok(p_aux[j]," \"\',!?");
					while(caut != NULL)
					{
						if(strcmp(caut,cuvant) == 0)
						nr++;
						caut = strtok(NULL," \"\',!?");
					}			
				}
				printf("%d",nr);		
				break;
				}
			case 2:
				{
				int j;		
				char *cuvant1 = (char*)malloc(sizeof(char)*100);
				char *cuvant2 = (char*)malloc(sizeof(char)*m);		
				scanf("%s %s",cuvant1,cuvant2);
				getchar();
				for(j = 0; j < n; j++)
				{
					char *caut =strstr(p[j],cuvant1);
					while(caut)					
					{
						if(strlen(cuvant1) == strlen(cuvant2))
							strncpy(caut,cuvant2,strlen(cuvant2));
						else {
							strcpy(caut+ strlen(cuvant2),caut+strlen(cuvant1));
							strncpy(caut,cuvant2,strlen(cuvant2));
						}
						caut =strstr(p[j],cuvant1);

					}
				}
				for(j = 0; j < n; j++)
					printf("%s",p[j]);	
				break;
				}
			case 3:
				{				
				scanf("%d",&k);
				getchar();
				int j, l;
				char **p_aux = (char**)malloc(sizeof(char*)*n);
				for(j = 0; j < n; j++)
				{
					p_aux[j] = (char*)malloc(sizeof(char)*1000);
					strcpy(p_aux[j], p[j]);
					char *caut = strtok(p_aux[j]," \"\',!?");
					
					while(caut != NULL)
					{	
						char *caut1 =strstr(p[j],caut);
						char *aux = (char*)malloc(sizeof(char)*100);
											
						for(l = 0; l < strlen(caut); l++)
							aux[(k+l) % strlen(caut)] = caut[l];
						strncpy(caut1,aux,strlen(aux));
						caut = strtok(NULL," \"\',!?\n");
											
					}			
				}
				for(j = 0; j < n; j++)
					printf("%s",p[j]);
				break;
				}
		}
	}
	return 0;
}		