function [R] = Power(nume, d, eps)
	f = fopen(nume);
	nr = (dlmread(f));
	%functie care citeste tot fisierul intr-o matrice n * m cu elemente reale
	%pune zerouri daca o linie este incompleta 
	[n m] = size(nr);
	A = zeros(nr(1, 1));
	K = zeros(nr(1, 1));
	C = zeros(nr(1, 1)); % K LA -1
	%nr(1, 1) este primul numar din fisierul de input(numarul de noduri)
	for i = 1 : nr(1,1)
		for j = 3 : nr(1, 1)
			if nr(i + 1, j) 
				A(i, nr(i + 1, j)) = 1;		%construirea matricei A
			endif
		endfor
		K(i, i) = nr(i + 1, 2);		%construirea matricei K
		if( A(i, i) == 1)
			K(i, i) --;		%scad 1 pentru pozitiile in care am 1 pe diag in A
			endif
		A(i, i) = 0;	%pun 0 pe diag daca am 1 in A
		C(i, i) = 1 / K(i, i);		%C = K ^ -1(inversez o matrice diagonala)
	endfor

	M = (C * A)';	%construirea matricei M(formula din pdf)

	E = ones(nr(1, 1));		%matrice cu toate elementele 1
	R = zeros(nr(1, 1), 1);
	R = R + 1 / nr(1, 1);
	%Construirea vectorului R(formula din pdf)
	do 
		B = R;
		R = (d * M + (1 - d) / nr(1, 1) * E) * R;
	until abs(R - B) / norm(R) < eps	
	fclose(f);
endfunction	