function [R] = Algebraic(nume, d)
	f = fopen(nume);
	nr = (dlmread(f));
	%functie care citeste tot fisierul intr-o matrice n * m cu elemente reale
	%pune zerouri daca o linie este incompleta 
	[n m] = size(nr);
	A = zeros(nr(1, 1));
	K = zeros(nr(1, 1));
	C = zeros(nr(1, 1)); % K LA -1
	%nr(1, 1) este primul numar din fisierul de input(numarul de noduri)
	for i = 1 : nr(1,1)
		for j = 3 : nr(1, 1)
			if nr(i + 1, j) 
				A(i, nr(i + 1, j)) = 1; %construirea matricei A
			endif
		endfor
		K(i, i) = nr(i + 1, 2);		%construirea matricei K
		if( A(i, i) == 1)
			K(i, i) --;		%scad 1 pentru pozitiile in care am 1 pe diag in A
			endif
		A(i, i) = 0;	%pun 0 pe diag daca am 1 in A
		C(i, i) = 1 / K(i, i);		%C = K ^ -1(inversez o matrice diagonala)
	endfor

	M = (C * A)'; 		%construirea matricei M(formula din pdf)

	R = zeros(nr(1, 1), 1);

	I = eye(nr(1, 1)); 		%In

	T = (I - d * M);	%calculez inversa matricei  I - d * M cu GS optimizat
	unu = ones(nr(1, 1), 1);	%vector coloana cu toate elementele 1
	T = abs(GramSchmidt(T));	%am pus abs pt ca in unele cazuri matricea 
	%inversa avea -0 in loc de 0, dar am vazut ca nu afecta rezultatul final
	%Construirea vectorului R(formula din pdf)
	R = T * (1 - d) / nr(1, 1) * unu;
	fclose(f);

endfunction