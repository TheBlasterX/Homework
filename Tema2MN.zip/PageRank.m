function [R1 R2 R3] = PageRank(nume, d, eps)
	R1 = Iterative(nume, d, eps); %vectorul obitnut la task1
	R2 = Algebraic(nume, d);	%vectorul obtinut la task2
	R3 = Power(nume, d, eps);	%vectorul obtinut la task3
	f = fopen(nume);
	nr = dlmread(f);
	%functie care citeste tot fisierul intr-o matrice n * m cu elemente reale
	%pune zerouri daca o linie este incompleta
	[n m] = size(nr);
	out = [nume, '.out']; 	%concatenez numele grafului cu .out
	g = fopen(out, 'w');	
	fprintf(g, '%d\n\n', nr(1,1));	%afisez numarul de noduri si las rand liber
	fprintf(g, '%f\n', R1);		%afiseaz vectorul de la task1
	
	fprintf(g, '\n');	%las rand liber
	fprintf(g, '%f\n', R2);		%afiseaz vectorul de la task2

	fprintf(g, '\n');	%las rand liber
	fprintf(g, '%f\n', R3);		%afiseaz vectorul de la task3
	
	val1 = nr(n - 1, 1);	%prima valoare din fisier pt task4
	val2 = nr(n, 1);		%a doua valoare din fisier pt task4
	R4 = zeros(m, 1);
	

	x = max(R2);
	indici = zeros(m, 1);
	%imi salvez intr-un vector de indici pozitiile numerelor din vectorul R2
	%in ordine descrescatoare a elementelor din vectorul R2
	%imi calculez max din vector inainte
	%parurg vectorul si cand gasesc val_max salvez indicele cu valoarea egala
	%cu pozitia elementului din vectorul R2
	%Apoi fac acest max = -1 si calulez din nou max din vector
	Ri = R2;  %am folosit un vector auxiliar pentru ca am nevoie de R2 la task4
    for j = 1 : m
    	for i = 1 : m
    		if single(Ri(i)) == single(x)
    %am folosit single pt ca aveam o problema cand aveam mai multe elemente
    %aparent egale(ele difereau abia la a 16-a zecimala) pentru a lua in calcul
    %mai putine zecimale			
    			indici(j) = i;
    			Ri(i) = -1;
    			x = max(Ri);
    			break;
    		endif
    	endfor
    endfor

    %apel functie de apartenenta
    for i = 1 : m
		R4(i) = Apartenenta(R2(i), val1, val2);
	endfor
	%am obtinut vectorul cerut de task4
	%acum il sortez cu bubble sort
    do
    	newn = 0;
        for i = 1 : m - 1
        	if R4(i) < R4(i + 1)
          		aux = R4(i);
          		R4(i) = R4(i + 1);
          		R4(i + 1) = aux;
            	newn = i;
            endif
        endfor
        ok = newn;
    until ok == 0

	fprintf(g, '\n');	%las rand liber

	for i = 1 : m
    	fprintf(g, '%d %d %f\n', i, indici(i), R4(i));
    %afisez indicii din R4, poz indicilor in vectorul R2 si vectorul R4(sortat)	
    endfor

	fclose(g);
	fclose(f);
endfunction