function [A] = GramSchmidt(A);
	%Algoritm descris in laborator in pseudocod
	%Algoritmul Gram-Schmidt optimizat pentru a descompune A in forma Q * R
	[n n] = size(A);
	Q = zeros(n);
	R = zeros(n);
	for i = 1 : n
		R(i, i) = norm(A(:, i));
		Q(:, i) = A(:, i) / R(i, i);
		for j  = 1 + i : n
			R(i, j) = Q(:, i)' * A(:, j);
			A(:, j) = A(:, j) - Q(:, i) * R(i, j);
		endfor
	endfor
%A = Q * R  (Q ^ -1) * A = R; Q ^ - 1 = Q';Q=ortogonala=>A ^ -1 = (R ^ -1) * Q'
	%INVERSARE MATRICE SUPERIOR TRIUNGHIULARA(algoritm de la curs)
	B = zeros(n);
	for j = n : -1 : 1
		B(j, j) = 1 / R(j, j);
		for i = j - 1 : -1 : 1
			B(i, j)= - R(i, i + 1 : j) * B(i + 1 : j, j) / R(i, i);
		endfor
	endfor
	B = triu(B);	
	%B = R ^ -1
	A = B * Q'; %Returnez A ^ -1
endfunction	