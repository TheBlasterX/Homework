function [y] = Apartenenta(x, val1, val2)
	if x < val1		%se stie ca x > 0
		y = 0;	%cand x < val1 y = 0
	else if x >= val1 && x <= val2		%cand val1<=x<=val2 y = a * x + b
			y = (x - val1) / (val2 - val1);	
		 else 	%se stie ca x < 1
		  		y = 1;		%cand x > val2 y = 0
		 endif
	endif	   			 		
endfunction