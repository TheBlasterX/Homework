/* Jipa Alexandru-Stefan - 311CB */
#include "TStiva-V.h"

//Initializarea cozii
AQV InitQ()
{
	AQV Q = malloc(sizeof(TCoada));
	if(!Q) return NULL;
	else return Q; 
}


//intializarea stivei
AST InitS()
{
	AST c = malloc(sizeof(TCoada));
	if(!c) return NULL;
	else return c; 
}

//afisarea stivei, cu ajutorul functiei f2
void AfisareS(AST S, FILE *f)
{
	if (S->vf == NULL ) return;
	TLG aux = S->vf;
	if(!aux) return;
	f2(aux, f);
}

//afisare cozii, cu ajutorul functiei f
void AfisareQ(AQV Q, FILE *g)
{
	
	fprintf(g, "{" );
	if (Q->ic == NULL )
	{
		fprintf(g, "}\n");
	return;
	}
	TLG aux = Q->ic;
	f(aux, g);
	fprintf(g, "}\n");
}

void f2(TLG aux, FILE *f)
{
	if (aux != NULL)
	{
	fprintf(f, "%d %s %s \n",((*(TSwitch*)aux->info).id),((*(TSwitch*)aux->info).ipv4),((*(TSwitch*)aux->info).Denumire));
	}
}

void f(TLG aux, FILE *g)
{
	if (aux != NULL)
	{
	fprintf(g, "%d ", (*(TSwitch*)aux->info).id);
	f(aux->next, g);
	}
}


//functia de adaugare, conform cerintei
void add(AST S[], AQV Q, int nr, char *nume_stiva, char *ip, char *tip, FILE *f)
{
	//adaugare in coada
	if(strcmp(tip, "SINGLE") == 0)
	{
		//alocare spatiu pt un element de tipul TSwitch
		TSwitch *aux = malloc(sizeof(TSwitch));
		if(!aux) return;
		aux->ipv4 = malloc(sizeof(50));
		if(!aux->ipv4)
		{	
			free(aux->ipv4);
			free(aux);
			return;
		}
		aux->Denumire = malloc(sizeof(50));
		if(!aux->Denumire) 
		{
			free(aux->Denumire);
			free(aux->ipv4);
			free(aux);
			return;
		}
		aux->mod = malloc(sizeof(50));
		if(!aux->mod) 
		{
			free(aux->mod);
			free(aux->Denumire);
			free(aux->ipv4);
			free(aux);
			return;
		}	
			aux->id = nr;
			memcpy(aux->ipv4, ip, strlen(ip) + 1);
			memcpy(aux->Denumire, nume_stiva, strlen(nume_stiva) + 1);
			memcpy(aux->mod, tip, strlen(tip) + 1);
			TLG al = malloc(sizeof(TCelulaG));
			al->info = malloc(sizeof(TSwitch));
			memcpy(al->info, aux, sizeof(TSwitch));

		//inserare in coada vida	
		if(Q->ic == NULL)
		{
			Q->ic = al;
		}

		//inserare in coada nevida
		else
		{	
    		int i = 0;
			TLG aux1 = Q->ic; 
			TLG aux2 = Q->ic;
			aux2 = aux1;
			for( ; aux1->next != NULL; aux1 = aux1->next)
			{	
				if(strcmp(((*(TSwitch*)aux1->info).ipv4), ((*(TSwitch*)aux).ipv4)) < 0)	
				{
					break;
				}
				i++;
			}	
			if(i == 0)
			{
				TLG bl = malloc(sizeof(TCelulaG));
				bl->info = malloc(sizeof(TSwitch));
				memcpy(bl->info, aux, sizeof(TSwitch));
				bl->next = al;
				aux2->next = bl;
				aux1->next = al;
			}
			else 	aux1->next = al;	
		}
	}	
	else
	//adaugare in stiva		
	{
		//alocare spatiu pt un element de tipul TSwitch
		TSwitch *aux = malloc(sizeof(TSwitch));
		if(!aux) return;
		aux->ipv4 = malloc(sizeof(50));
		if(!aux->ipv4)
		{	
			free(aux->ipv4);
			free(aux);
			return;
		}
		aux->Denumire = malloc(sizeof(50));
		if(!aux->Denumire) 
		{
			free(aux->Denumire);
			free(aux->ipv4);
			free(aux);
			return;
		}
		aux->mod = malloc(sizeof(50));
		if(!aux->mod) 
		{
			free(aux->mod);
			free(aux->Denumire);
			free(aux->ipv4);
			free(aux);
			return;
		}	
			aux->id = nr;
			memcpy(aux->ipv4, ip, strlen(ip) + 1);
			memcpy(aux->Denumire, nume_stiva, strlen(nume_stiva) + 1);
			memcpy(aux->mod, tip, strlen(tip) + 1);
			TLG al = malloc(sizeof(TCelulaG));
			al->info = malloc(sizeof(TSwitch));
			memcpy(al->info, aux, sizeof(TSwitch));
			char* tip = malloc(30);
			int id;
			fscanf(f,"%d %s ", &id, tip);
		//adaugare in stiva vida	
		if(S[id]->vf == NULL)
		{
			S[id]->vf = al;
			S[id]->b = al;
		}
		//adaugare in stiva nevida
		else
		{
			 al->next = S[id]->vf; 
				S[id]->vf = al;
		}
	}
}										