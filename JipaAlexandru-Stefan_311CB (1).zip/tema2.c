/* Jipa Alexandru-Stefan - 311CB */
#include "TStiva-V.h"

int main(int args, char *argv[])
{
	FILE *switch_input = fopen(argv[1],"r");
	FILE *switch_output = fopen(argv[2],"w");
	int nr_stive;
	fscanf(switch_input, "%d", &nr_stive);
	AST stiva[nr_stive]; 	//vectorul de stive
	AQV coada;
	char* nume = malloc(50);		//denumirea 
	char* ip = malloc(30); 
	char* tip = malloc(30);		//modul de lucru(stiva/coada)
	char* cond = malloc(30);	//tipul intstructiunii

	int nr,i;//id-ul switch-ului
	coada = InitQ();
	for(i = 0; i < nr_stive; i++)
	{
		stiva[i] = InitS();
	}

	for( ; fscanf(switch_input, "%s ", cond) != EOF; )
	{
		if(strcmp(cond, "set") == 0)
		{
		
		}

		if(strcmp(cond, "add") == 0)
		{
			fscanf(switch_input,"%d %s %s %s", &nr, nume, ip, tip);
			add(stiva, coada, nr, nume, ip, tip, switch_input);
		}
		
		if(strcmp(cond, "del") == 0)
		{
			
		}

		if(strcmp(cond, "show") == 0)
		{	
			AfisareQ(coada, switch_output);
			for(i = 0; i < nr_stive; i++)
			{
				fprintf(switch_output ,"%d:\n", i );
				AfisareS(stiva[i], switch_output);
				fprintf(switch_output, "\n");
			}

		}
		
		if(strcmp(cond, "ipmin") == 0)
		{
		
		}	
	}
	fclose(switch_input);
	fclose(switch_output);
	return 0;
}
