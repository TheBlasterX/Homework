/* Jipa Alexandru-Stefan - 311CB */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>

#ifndef _STIVA_
#define _STIVA_
typedef struct celulag
{ 
  void* info;           /* adresa informatie */
  struct celulag *next;   /* adresa urmatoarei celule */
}TCelulaG, *TLG, **ALG; /* tipurile Celula, Lista si Adresa_Lista */

//tipul structurii TSwitch
typedef struct
{
	int id;
	char *Denumire, *ipv4, *mod;
}TSwitch;

typedef struct
{
	TCelulaG *ic;   /*inceputul cozii*/
}TCoada, *AQV;

typedef struct
{ 
	TLG b;			/* adresa de inceput a vectorului / baza stivei */
	TLG vf; 		/* varful stivei 								*/
}TStiva, *AST;

/*- macrodefinitii - acces campuri */
#define DIME(a) (((ASt)(a))->dime)
#define BS(a) 	(((ASt)(a))->b)
#define SV(a) 	(((ASt)(a))->sv)
#define VF(a) 	(((ASt)(a))->vf)

/*- teste -*/
/* verifica daca doua stive au elemente de dimensiuni diferite */
#define DIMDIF(s,d)	(DIME(s) != DIME(d))
/* verifica daca o stiva este vida */
#define VIDA(a)  	(VF(a) == BS(a))
/* verifica daca stiva este plina */
#define PLINA(a) 	(VF(a) == SV(a))
void AfisareS(AST S, FILE*f);
AST InitS();
void f2(TLG aux, FILE *f);
void f(TLG aux, FILE *g);
void AfisareQ(AQV Q, FILE *g);
void add(AST S[], AQV Q, int nr, char *nume_stiva, char *ip, char *tip, FILE *f);
AQV InitQ();

#endif
