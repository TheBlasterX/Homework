/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Stefan Jipa
 * Contine atributele clasei romb, constructori, get-eri si metoda point_in pt a verifica daca un punct se afla in romb
 */
public class Rhombus extends Quadtree {

    double x1;
    double y1;
    double x2;
    double y2;
    double x3;
    double y3;
    double x4;
    double y4;
    int idd;

    /**
     * 
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param x3
     * @param y3
     * @param x4
     * @param y4
     * @param idd 
     * Constructor cu paramatrii ce initializeaza atributele unui romb
     * x1, y1 coltul de sus, x2, y2 coltul din stanga, x3, y3 coltul de jos, x4, y4 coltul din dreapta, si idd id-ul figurii
     * Punctul 1 il inversez cu Punctul 3 deoarece sunt date invers in fisierul de intrare
     */
    public Rhombus(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4, int idd) {
        this.x1 = x3;
        this.y1 = y3;
        this.x2 = x2;
        this.y2 = y2;
        this.x3 = x1;
        this.y3 = y1;
        this.x4 = x4;
        this.y4 = y4;
        this.idd = idd;
    }

    /**
     * Constructor fara parametrii
     */
    public Rhombus() {
    }

    /**
     * 
     * @return 
     * Get-er pt a obtine id-ul rombului
     */
    @Override
    public int getId() {
        return idd;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine x1 al dreptunghiului incadrator al rombului
     */
    @Override
    public double getX1() {
        return x2;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine y1 al dreptunghiului incadrator al rombului
     */
    @Override
    public double getY1() {
        return y3;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine x2 al dreptunghiului incadrator al rombului
     */
    @Override
    public double getX2() {
        return x4;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine y2 al dreptunghiului incadrator al rombului
     */
    @Override
    public double getY2() {
        return y1;
    }

    /**
     * 
     * @param x
     * @param y
     * @return
     * Verific daca un punct apartine rombului
     * Aceasta metoda epeleaza o alta metoda de 2 ori
     * Aici sparg rombul in 2 triunghiuri si verific daca punctul dat apartine macar unui triunghi din cele 2
     * Metoda Point_in_Rhombus2 verifica daca 1 pct se afla in triunghi (se bazeaza pe formula lui Heron)
     */
    @Override
    public boolean Point_in(double x, double y) {
        boolean ans1;
        boolean ans2;
        Point_collision VR = new Point_collision();
        ans1 = VR.Point_in_Rhombus2(x, y, x1, y1, x2, y2, x3, y3);
        ans2 = VR.Point_in_Rhombus2(x, y, x1, y1, x3, y3, x4, y4);
        return (ans1 || ans2);
    }
}
