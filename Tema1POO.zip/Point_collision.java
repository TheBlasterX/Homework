/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static java.lang.Math.abs;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 *
 * @author Stefan Jipa
 * In aceasta clasa am o singura metoda pe cale o apeleaza metoda Point_in din clasa Rhombus, metoda ce imparte rombul in 2 triunghiuri
 * In metoda Point_Rhombus2 verific daca un punct apartine triunghiului primit ca parametru de la metoda mentionata mai sus
 */
public class Point_collision extends Quadtree {

    /**
     * Constructor fara parametru
     */
    public Point_collision() {
    }

    /**
     * 
     * @param x
     * @param y
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param x3
     * @param y3
     * @return
     * Verifica daca punctul apartine triunghiului
     * Folosesc formula lui Heron
     * Formez 3 triunghiuri cu cate 2 varfuri ale triunghiului de baza si cu punctul dat
     * Calculez cele 3 arii si aria triunghiului mare
     * Daca aceastea suma celor 3 arii = aria triunghiului mare at punctul apartine triunghiului
     * Am luat in considerare o eroare de 0.000001, deoarece se mai pierd din zecimale din cauza radicalilor
     */
    public boolean Point_in_Rhombus2(double x, double y, double x1, double y1, double x2, double y2, double x3, double y3) {
        double L1 = sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2));
        double L2 = sqrt(pow((x3 - x2), 2) + pow((y3 - y2), 2));
        double L3 = sqrt(pow((x1 - x3), 2) + pow((y1 - y3), 2));
        double sp = (L1 + L2 + L3) / 2;     //semiperimetru
        double A = sqrt(sp * (sp - L1) * (sp - L2) * (sp - L3));
        double L4 = sqrt(pow((x1 - x), 2) + pow((y1 - y), 2));
        double L5 = sqrt(pow((x - x2), 2) + pow((y - y2), 2));
        double L6 = sqrt(pow((x - x3), 2) + pow((y - y3), 2));
        double sp1 = (L1 + L4 + L5) / 2;     //semiperimetru
        double A1 = sqrt(sp1 * (sp1 - L1) * (sp1 - L4) * (sp1 - L5));
        double sp2 = (L5 + L2 + L6) / 2;     //semiperimetru
        double A2 = sqrt(sp2 * (sp2 - L5) * (sp2 - L2) * (sp2 - L6));
        double sp3 = (L4 + L6 + L3) / 2;     //semiperimetru
        double A3 = sqrt(sp3 * (sp3 - L4) * (sp3 - L6) * (sp3 - L3));
        return abs(A - A1 - A2 - A3) < 0.000000001;

    }

}
