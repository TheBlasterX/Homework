/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Stefan Jipa
 * Aceasta clasa contine metoda main , care nu face nimic altceva decat sa apeleze metoda de citire, care se afla in clasa READ
 */
public class Tema1 {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        Read Toread = new Read();
        Toread.StartReading();
    }
}
