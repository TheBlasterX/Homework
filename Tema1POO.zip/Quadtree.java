/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Stefan Jipa
 * Aceasta clasa contine quadtree-ul si atributele sale
 * Contine constructori cu parametru si fara
 * Contine get-eri, dar au ca scop sa pot face override pe ei, deoarece toate clasele de figuri geometrice extind clasa quadtree
 * Contine metode: de inserare a unei figuri in arbore, de a sterge un nod(sau mai multe), coliziune cu punct, coliziune cu figura si o metoada prin care imi obtin cadranul in care ma aflu.
 */
public class Quadtree {

    double xc1;         //pt imagine,cadrane(coordonatele imaginii initiale)
    double yc1;
    double xc2;
    double yc2;
    int id;             //figura
    Quadtree obj[];     //vector de obiecte(in caz ca am coliziune sa pot pune mai multe obiecte intr-un nod)
    int size;           //contor pt a stii cate elemente am intr-un nod
    Quadtree root[];    //vector pentru numarul de fii( care va fi setat pe 4)

    /**
     * Constuctor fara parametrii
     */
    public Quadtree() {
    }

    /**
     * 
     * @param x
     * @param y
     * @return
     * Metoda ce este suprascrisa din clasele de tip figuri geometrice
     */
    public boolean Point_in(double x, double y) {
        return false;
    }

    /**
     * 
     * @param xc1
     * @param yc1
     * @param xc2
     * @param yc2
     * @param object
     * Constructor cu parametrii
     * Initializeaza xc1, yc1, xc2, yc2 (initial sunt coordonatele imaginii de start)
     * Aloc 1000 de obiecte pentru un nod
     * Pun obiectul in poz 0 a vectorului de obiecte dintr-un nod
     * lungimea vectorului devine 1, intial
     */
    public Quadtree(double xc1, double yc1, double xc2, double yc2, Quadtree object) {
        this.xc1 = xc1;
        this.yc1 = yc1;
        this.xc2 = xc2;
        this.yc2 = yc2;
        this.obj = new Quadtree[1000];
        root = new Quadtree[4];
        this.obj[0] = object;
        size = 1;
    }
    
    /**
     * 
     * @param xc1
     * @param yc1
     * @param xc2
     * @param yc2
     * @param obj
     * @return
     * Verific daca Obiectul dat (fig geometrica) se intersecteaza cu cadranul dat ca parametru prin coordonatele xc1, yc1, xc2 si yc2
     */
    public boolean point_collision(double xc1, double yc1, double xc2, double yc2, Quadtree obj) {
        if ((obj.getX1() >= xc1 && obj.getY1() >= yc1 && obj.getX1() <= xc2 && obj.getY1() <= yc2)
                || (obj.getX2() >= xc1 && obj.getY1() >= yc1 && obj.getX2() <= xc2 && obj.getY1() <= yc2)
                || (obj.getX1() >= xc1 && obj.getY2() >= yc1 && obj.getX1() <= xc2 && obj.getY2() <= yc2)       //unul dintre colturile figur-ii se gaseste in cadrana
                || (obj.getX2() >= xc1 && obj.getY2() >= yc1 && obj.getX2() <= xc2 && obj.getY2() <= yc2))      //obiect in cadran
            return true;
       
        if ((obj.getX1() <= xc1 && obj.getY1() <= yc1 && obj.getX2() >= xc1 && obj.getY2() >= yc1)
                || (obj.getX1() <= xc2 && obj.getY1() <= yc2 && obj.getX2() >= xc2 && obj.getY1() >= yc2)
                || (obj.getX1() <= xc2 && obj.getY1() <= yc2 && obj.getX2() >= xc2 && obj.getY2() >= yc2)       //unul dintre colturile cadranului se gaseste in figura
                || (obj.getX2() >= xc1 && obj.getY2() >= yc1 && obj.getX1() <= xc1 && obj.getY1() <= yc1))      //cadran apartine obiect
        
            return true;
        
        return obj.getX1() < xc1 && obj.getY1() > yc1 && obj.getX2() > xc2 && obj.getY2() < yc2                 //caz in care obj-ul intersecteaza cadranul dar niciun colt nu se afla in intersectie
                || obj.getX1() > xc1 && obj.getY1() < yc1 && obj.getX2() < xc2 && obj.getY2() > yc2;            //nici al obj-ului, nici al figurii
    }

    /**
     * 
     * @param parent
     * @param id
     * Metoda ce sterge toate obiectele care au id-ul dat din arbore
     * Parcurg tot arborele recursiv, si cand gasesc id-ul dat sterg obiectul cu acest id 
     */
    void sterge_nod(Quadtree parent, int id) {
        if (parent != null) {
            for (int i = 0; i <= 3; i++) {
                if (parent.root[i] != null) {
                    int size1 = parent.root[i].size;
                    sterge_nod(parent.root[i], id);
                    if (size1 > 0) {
                        for (int j = 0; j < size1; j++) {
                            if (parent.root[i].obj[j].getId() == id) {
                                if (parent.root[i].size >= 2 || i != parent.root[i].size) {
                                    parent.root[i].obj[j] = parent.root[i].obj[size1 - 1];
                                } else {
                                    parent.root[i].obj[j] = null;
                                }
                                parent.root[i].size--;
                                size1--;
                                break;
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 
     * @param parent
     * @param x
     * @param y
     * @param ids
     * @param contor
     * @return
     * Parcurg tot arborele recursiv
     * Verifica daca punctul dat se afla in fiecare figura
     * Daca da, ii adaug id-ul figurii in vectorul ids de figuri si faca si un contor ca sa stiu cate idu-ri am in vector
     * Pentru a nu le parurge si pe cele cu valoarea 0( de la initializarea vectorului)
     */
    int[] opeartion3(Quadtree parent, double x, double y, int[] ids, int[] contor) {
        if (parent != null) {
            if (parent.size > 0) {
                {
                    for (int i = 0; i < parent.size; i++) {
                        if (parent.obj[i].Point_in(x, y)) {
                            ids[contor[0]] = parent.obj[i].getId();
                            contor[0]++;
                        }
                    }
                }

            }
            ids = opeartion3(parent.root[0], x, y, ids, contor);
            ids = opeartion3(parent.root[1], x, y, ids, contor);
            ids = opeartion3(parent.root[2], x, y, ids, contor);
            ids = opeartion3(parent.root[3], x, y, ids, contor);
        }
        return ids;
    }

    /**
     * 
     * @param parent
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param ids
     * @param contor
     * @return
     * Verfica daca figura data face coliziunea cu alte figuri
     * Parurg arborele recursiv
     * Verifica daca figura data face coliziune cu toate figurile din arbore, cu ajutorul metodei point_collision
     * Pe care o foloseam in mod asemanator la interesectia intre cadran si figura
     * Daca da, ii adaug id-ul figurii in vectorul ids de figuri si faca si un contor ca sa stiu cate idu-ri am in vector
     * Pentru a nu le parurge si pe cele cu valoarea 0( de la initializarea vectorului)
     */
    int[] operation4(Quadtree parent, double x1, double y1, double x2, double y2, int[] ids, int[] contor) {
        if (parent != null) {
            if (parent.size > 0) {
                for (int i = 0; i < parent.size; i++) {
                    if (parent.obj[i].point_collision(x1, y1, x2, y2, parent.obj[i])) {
                        ids[contor[0]] = parent.obj[i].getId();
                        contor[0]++;
                    }
                }
            }
            ids = operation4(parent.root[0], x1, y1, x2, y2, ids, contor);
            ids = operation4(parent.root[1], x1, y1, x2, y2, ids, contor);
            ids = operation4(parent.root[2], x1, y1, x2, y2, ids, contor);
            ids = operation4(parent.root[3], x1, y1, x2, y2, ids, contor);
        }
        return ids;
    }

    /**
     * Aceasta metoda realizeaza inserarea unui obiect(figuri geometrice in arbore)
     * Verific de fiecare data cu ce cadran se intersecteaza figura data(pot fi si mai multe)
     * Daca obiectul dat face coliziune cu alt punct il pun in acelasi nod in vectorul de obiecte
     * Daca intr-un cadran am deja alt obiect, dar nu este coliziune, impart cadranul dat in 4 si verific iar unde ar trebui reasezate figurile (in subcadrane)
     * Fac acelasi lucru pentru fiecare cadran
     * @param parent
     * @param object
     */
    public void insert(Quadtree parent, Quadtree object) {
        double coord[] = ret_cadran(1, parent);
        if (object != null && point_collision(coord[0], coord[1], coord[2], coord[3], object)) {
            if (parent.root[0] != null) {
                if (parent.root[0].size > 0) {
                    int ok = 0;
                    int p = parent.root[0].size;
                    for (int i = 0; i < p; i++) {
                        if (point_collision(parent.root[0].obj[i].getX1(), parent.root[0].obj[i].getY1(), parent.root[0].obj[i].getX2(), parent.root[0].obj[i].getY2(), object)) {
                            ok++;
                        }
                    }
                    if (ok == parent.root[0].size) {
                        parent.root[0].obj[parent.root[0].size] = object;
                        parent.root[0].size++;
                    } else {
                        int e = parent.root[0].size;
                        for (int i = 0; i < e; i++) {
                            insert(parent.root[0], parent.root[0].obj[i]);
                        }
                        insert(parent.root[0], object);
                        parent.root[0].size = 0;
                        parent.root[0].obj = null;
                    }
                } else {
                    insert(parent.root[0], object);
                }
            } else {
                parent.root[0] = new Quadtree(coord[0], coord[1], coord[2], coord[3], object);
            }
        }
        
        coord = ret_cadran(2, parent);
        if (object != null && point_collision(coord[0], coord[1], coord[2], coord[3], object)) {
            {
                if (parent.root[1] != null) {
                    if (parent.root[1].size > 0) {
                        int ok = 0;
                        int p = parent.root[1].size;
                        for (int i = 0; i < p; i++) {
                            if (point_collision(parent.root[1].obj[i].getX1(), parent.root[1].obj[i].getY1(), parent.root[1].obj[i].getX2(), parent.root[1].obj[i].getY2(), object)) {
                                ok++;
                            }
                        }
                        if (ok == parent.root[1].size) {
                            parent.root[1].obj[parent.root[1].size] = object;
                            parent.root[1].size++;
                        } else {
                            int e = parent.root[1].size;
                            for (int i = 0; i < e; i++) {
                                insert(parent.root[1], parent.root[1].obj[i]);
                            }
                            insert(parent.root[1], object);
                            parent.root[1].size = 0;
                            parent.root[1].obj = null;

                        }
                    } else {
                        insert(parent.root[1], object);
                    }
                } else {
                    parent.root[1] = new Quadtree(coord[0], coord[1], coord[2], coord[3], object);
                }
            }
        }
        
        coord = ret_cadran(3, parent);
        if (point_collision(coord[0], coord[1], coord[2], coord[3], object)) {
            if (parent.root[2] != null) {
                if (parent.root[2].size > 0) {
                    int ok = 0;
                    int p = parent.root[2].size;
                    for (int i = 0; i < p; i++) {
                        if (point_collision(parent.root[2].obj[i].getX1(), parent.root[2].obj[i].getY1(), parent.root[2].obj[i].getX2(), parent.root[2].obj[i].getY2(), object)) {
                            ok++;
                        }
                    }
                    if (ok == parent.root[2].size) {
                        parent.root[2].obj[parent.root[2].size] = object;
                        parent.root[2].size++;
                    } else {
                        int e = parent.root[2].size;
                        for (int i = 0; i < e; i++) {
                            insert(parent.root[2], parent.root[2].obj[i]);
                        }
                        insert(parent.root[2], object);
                        parent.root[2].size = 0;
                        parent.root[2].obj = null;
                    }
                } else {
                    insert(parent.root[2], object);
                }
            } else {
                parent.root[2] = new Quadtree(coord[0], coord[1], coord[2], coord[3], object);
            }
        }
        
        coord = ret_cadran(4, parent);
        if (point_collision(coord[0], coord[1], coord[2], coord[3], object)) {
            if (parent.root[3] != null) {
                if (parent.root[3].size > 0) {
                    int ok = 0;
                    int p = parent.root[3].size;
                    for (int i = 0; i < p; i++) {
                        if (point_collision(parent.root[3].obj[i].getX1(), parent.root[3].obj[i].getY1(), parent.root[3].obj[i].getX2(), parent.root[3].obj[i].getY2(), object)) {
                            ok++;
                        }
                    }
                    if (ok == parent.root[3].size) {
                        parent.root[3].obj[parent.root[3].size] = object;
                        parent.root[3].size++;
                    } else {
                        int e = parent.root[3].size;
                        for (int i = 0; i < e; i++) {
                            insert(parent.root[3], parent.root[3].obj[i]);
                        }
                        insert(parent.root[3], object);
                        parent.root[3].size = 0;
                        parent.root[3].obj = null;
                    }
                } else {
                    insert(parent.root[3], object);
                }
            } else {
                parent.root[3] = new Quadtree(coord[0], coord[1], coord[2], coord[3], object);
            }
        }
    }

    /**
     * 
     * @param nr_cadran
     * @param parent
     * @return
     * Metoda ce imi returneaza coordonatele cadranului (subcadranului) dorit(1, 2, 3 ,4)
     */
    public double[] ret_cadran(int nr_cadran, Quadtree parent) {
        double[] coord = new double[4];
        switch (nr_cadran) {
            case 1:
                coord[0] = (parent.xc1 + parent.xc2) / 2;       //x1
                coord[1] = (parent.yc1 + parent.yc2) / 2;       //y1
                coord[2] = parent.xc2;                          //x2
                coord[3] = parent.yc2;                          //y2
                break;
            case 2:
                coord[0] = parent.xc1;                          //x1
                coord[1] = (parent.yc1 + parent.yc2) / 2;       //y1
                coord[2] = (parent.xc1 + parent.xc2) / 2;       //x2
                coord[3] = parent.yc2;                          //y2
                break;
            case 3:
                coord[0] = parent.xc1;                          //x1
                coord[1] = parent.yc1;                          //y1
                coord[2] = (parent.xc1 + parent.xc2) / 2;       //x2
                coord[3] = (parent.yc1 + parent.yc2) / 2;       //y2
                break;
            default:
                coord[0] = (parent.xc1 + parent.xc2) / 2;       //x1
                coord[1] = parent.yc1;                          //y1
                coord[2] = parent.xc2;                          //x2
                coord[3] = (parent.yc1 + parent.yc2) / 2;       //y2
                break;
        }
        return coord;
    }

    /**
     * 
     * @return
     * Get-er este suprascrisa din clasele de tip figuri geometrice
     */
    public int getId() {
        return id;
    }

    /**
     * 
     * @return 
     * Get-er este suprascrisa din clasele de tip figuri geometrice
     */
    public double getX1() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * 
     * @return
     * Get-er este suprascrisa din clasele de tip figuri geometrice
     */
    public double getY1() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * 
     * @return
     * Get-er este suprascrisa din clasele de tip figuri geometrice
     */
    public double getX2() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * 
     * @return
     * Get-er este suprascrisa din clasele de tip figuri geometrice
     */
    public double getY2() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
