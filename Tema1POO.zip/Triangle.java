/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static java.lang.Math.abs;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

/**
 *
 * @author Stefan Jipa
 * Aceasta clasa contine toate atributele unui triunghi, constructori, get-eri si metoda Point_in cu scopul de a verifica daca un punct se afla in triunghi
 */
public class Triangle extends Quadtree {

    double x1;
    double y1;
    double x2;
    double y2;
    double x3;
    double y3;
    int idd;

    /**
     * 
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param x3
     * @param y3
     * @param idd
     * Constructor cu paramatrii ce initializeaza atributele unui triunghi
     * x1, y1 coltul de sus , x2, y2 coltul din stanga, x3, y3 coltul din dreapta si idd (id-ul) sunt initializate
     */
    public Triangle(double x1, double y1, double x2, double y2, double x3, double y3, int idd) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.x3 = x3;
        this.y3 = y3;
        this.idd = idd;
    }

    /**
     * Constructor fara parametrii
     */
    public Triangle() {
    }

    /**
     * 
     * @return 
     * Get-er pt a obtine id al triunghiului
     */
    @Override
    public int getId() {
        return idd;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine x1 al dreptunghiului incadrator al triunghiului
     */
    @Override
    public double getX1() {
        return x2;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine y1 al dreptunghiului incadrator al triunghiului
     */
    @Override
    public double getY1() {
        return y2;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine x2 al dreptunghiului incadrator al triunghiului
     */
    @Override
    public double getX2() {
        return x3;
    }

    /**
     * 
     * @return
     * Get-er pt a obtine y2 al dreptunghiului incadrator al triunghiului
     */
    @Override
    public double getY2() {
        return y1;
    }

    /**
     * 
     * @param x
     * @param y
     * @return
     * Verifica daca punctul apartine triunghiului
     * Folosesc formula lui Heron
     * Formez 3 triunghiuri cu cate 2 varfuri ale triunghiului de baza si cu punctul dat
     * Calculez cele 3 arii si aria triunghiului mare
     * Daca aceastea suma celor 3 arii = aria triunghiului mare at punctul apartine triunghiului
     * Am luat in considerare o eroare de 0.000001, deoarece se mai pierd din zecimale din cauza radicalilor
     */
    @Override
    public boolean Point_in(double x, double y) {
        double L1 = sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2));
        double L2 = sqrt(pow((x3 - x2), 2) + pow((y3 - y2), 2));
        double L3 = sqrt(pow((x1 - x3), 2) + pow((y1 - y3), 2));
        double sp = (L1 + L2 + L3) / 2;     //semiperimetru triunghi mare
        double A = sqrt(sp * (sp - L1) * (sp - L2) * (sp - L3));
        double L4 = sqrt(pow((x1 - x), 2) + pow((y1 - y), 2));
        double L5 = sqrt(pow((x - x2), 2) + pow((y - y2), 2));
        double L6 = sqrt(pow((x - x3), 2) + pow((y - y3), 2));
        double sp1 = (L1 + L4 + L5) / 2;     //semiperimetru triunghi 1
        double A1 = sqrt(sp1 * (sp1 - L1) * (sp1 - L4) * (sp1 - L5));
        double sp2 = (L5 + L2 + L6) / 2;     //semiperimetru trunghi 2
        double A2 = sqrt(sp2 * (sp2 - L5) * (sp2 - L2) * (sp2 - L6));
        double sp3 = (L4 + L6 + L3) / 2;     //semiperimetru triunghi 3
        double A3 = sqrt(sp3 * (sp3 - L4) * (sp3 - L6) * (sp3 - L3));
        if (A == A1 + A2 + A3) {
            return true;
        } else if (abs(A - A1 - A2 - A3) < 0.000001) {
            return true;
        }
        return false;

    }

}
