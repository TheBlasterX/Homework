/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Stefan Jipa Clasa aceasta contine atributele unui dreptunghi,
 * constructori, get-eri si metoda Point_in cu rol de a verifica daca un punct
 * se afla in dreptunghi
 */
public class Rectangle extends Quadtree {

    double x1;
    double y1;
    double x2;
    double y2;
    int idd;

    /**
     *
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @param idd 
     * Constructorul cu parametrii al clasei Rectangle: x1, y1 si x2, y2 coordonatele coltului stanga jos, respectiv stanga sus 
     * id-ul dreptunghiului. Initializeaza toate aceste atribute ale clasei
     */
    public Rectangle(double x1, double y1, double x2, double y2, int idd) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
        this.idd = idd;
    }

    /**
     * Constructor fara parametrii al aceastei clase
     */
    public Rectangle() {
    }

    /**
     * 
     * @param x
     * @param y
     * @return
     * Aflu daca un punct apartine dreptunghiului
     */
    @Override
    public boolean Point_in(double x, double y) {
        return (x >= x1 && x <= x2 && y >= y1 && y <= y2);
    }

    /**
     * 
     * @return
     * Get-er pt id
     */
    @Override
    public int getId() {
        return idd;
    }

    /**
     * 
     * @return 
     *Get-er pt X1
     */
    @Override
    public double getX1() {
        return x1;
    }

    /**
     * 
     * @return
     * Get-er pt Y1
     */
    @Override
    public double getY1() {
        return y1;
    }

    /**
     * 
     * @return
     * Get-er pt X2
     */
    @Override
    public double getX2() {
        return x2;
    }

    /**
     *
     * @return
     * Get-er pt Y2
     */
    @Override
    public double getY2() {
        return y2;
    }

}
