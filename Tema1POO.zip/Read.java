/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Stefan Jipa
 */
public class Read {

    public Read() {
    }

    /**
     * 
     * In aceasta metoda citesc fisierul de intrare cu ajutorul a 3 switch-uri(tot-ul fiind intr-o repetitiva care citeste pana la finalul fisierului
     * In primul switch citesc tipul operatiei: 11 pentru adugare, 22 stergere, 33 coliziune punct, 44 coliziune figura
     * Inainte de repetitiva citesc coordonatele imaginii mari
     * In al doilea switch citesc tipul figurii de inserat( pt operatia 11)
     * In al treilea switch citesc tipul figurii de cautat coliziuni
     * Tot aceasta metoda face si scrierea in fisier
     * Daca vectorul de id-uri are numai 0-uri afisez NIL
     * Daaca nu, sortez vectorul si afiez pe cate o line id-urile separate prin spatii, fara a pune spatiu la final de line pentru fiecare operatie 33 sau 44
     * De asemenea din aceasta metoda apelez cele 4 operatii cerute in tema
     * @throws FileNotFoundException
     * @throws IOException 
     */
    public void StartReading() throws FileNotFoundException, IOException {
        Scanner ReadFile = new Scanner(new File("quadtree.in"));

        double coordinates[] = new double[4];
        int i;
        for (i = 0; i <= 3; i++) {
            coordinates[i] = ReadFile.nextDouble();
        }
        int operation;
        int geometric_object;
        int id;
        Quadtree tree = new Quadtree(coordinates[0], coordinates[1], coordinates[2], coordinates[3], new Rectangle(0, 0, 0, 0, 0));
        PrintWriter out = new PrintWriter("quadtree.out");

        for (; ReadFile.hasNext();) {
            operation = ReadFile.nextInt();
            switch (operation) {
                case 11://add
                    geometric_object = ReadFile.nextInt();

                    switch (geometric_object) {
                        case 1: //dreptunghi
                            double coordRE[] = new double[4];
                            id = ReadFile.nextInt();
                            for (i = 0; i <= 3; i++) {
                                coordRE[i] = ReadFile.nextDouble();
                            }
                            Rectangle Rect = new Rectangle(coordRE[0], coordRE[1], coordRE[2], coordRE[3], id);
                            tree.insert(tree, Rect);
                            break;

                        case 2://triunghi
                            double coordTR[] = new double[6];
                            id = ReadFile.nextInt();
                            for (i = 0; i <= 5; i++) {
                                coordTR[i] = ReadFile.nextDouble();
                            }
                            Triangle TR = new Triangle(coordTR[0], coordTR[1], coordTR[2], coordTR[3], coordTR[4], coordTR[5], id);
                            tree.insert(tree, TR);
                            break;

                        case 3://Cerc
                            double coordC[] = new double[2];
                            id = ReadFile.nextInt();
                            double radius = ReadFile.nextDouble();
                            for (i = 0; i <= 1; i++) {
                                coordC[i] = ReadFile.nextDouble();
                            }
                            Circle C = new Circle(radius, coordC[0], coordC[1], id);
                            tree.insert(tree, C);
                            break;

                        case 4://Romb
                            double coordRO[] = new double[8];
                            id = ReadFile.nextInt();
                            for (i = 0; i <= 7; i++) {
                                coordRO[i] = ReadFile.nextDouble();
                            }
                            Rhombus RO = new Rhombus(coordRO[0], coordRO[1], coordRO[2], coordRO[3], coordRO[4], coordRO[5], coordRO[6], coordRO[7], id);
                            tree.insert(tree, RO);
                            break;
                    }
                    break;

                case 22://sterge
                    id = ReadFile.nextInt();
                    tree.sterge_nod(tree, id);
                    break;

                case 33://coliziune cu punct    
                    double x;
                    double y;
                    x = ReadFile.nextDouble();
                    y = ReadFile.nextDouble();
                    int[] ids = new int[10000];
                    int[] k = new int[1];
                    ids = tree.opeartion3(tree, x, y, ids, k);
                    if (ids[0] == 0) {
                        out.println("NIL");
                    } else {
                        Arrays.sort(ids);
                        for (i = 10000 - k[0]; i < 10000; i++) {
                            if (ids[i] != 0 && ids[i] != ids[i - 1] && i != 0) {
                                if (ids[i] == ids[9999]) {
                                    out.println(ids[i]);
                                } else {
                                    out.print(ids[i] + " ");
                                }
                            }
                        }
                    }
                    break;

                case 44:
                    geometric_object = ReadFile.nextInt();

                    switch (geometric_object) {
                        case 1: //dreptunghi
                            double coordRE[] = new double[4];
                            for (i = 0; i <= 3; i++) {
                                coordRE[i] = ReadFile.nextDouble();
                            }
                            int[] ids1 = new int[10000];
                            int[] k1 = new int[1];
                            ids1 = tree.operation4(tree, coordRE[0], coordRE[1], coordRE[2], coordRE[3], ids1, k1);
                            if (ids1[0] == 0) {
                                out.println("NIL");
                            } else {
                                Arrays.sort(ids1);
                                for (i = 10000 - k1[0]; i < 10000; i++) {
                                    if (ids1[i] != 0 && ids1[i] != ids1[i - 1] && i != 0) {
                                        if (ids1[i] == ids1[9999]) {
                                            out.println(ids1[i]);
                                        } else {
                                            out.print(ids1[i] + " ");
                                        }
                                    }
                                }
                            }
                            break;

                        case 2://triunghi
                            double coordTR[] = new double[6];
                            for (i = 0; i <= 5; i++) {
                                coordTR[i] = ReadFile.nextDouble();
                            }
                            int[] ids2 = new int[10000];
                            int[] k2 = new int[1];
                            Triangle TR = new Triangle(coordTR[0], coordTR[1], coordTR[2], coordTR[3], coordTR[4], coordTR[5], 0);
                            ids2 = tree.operation4(tree, TR.getX1(), TR.getY1(), TR.getX2(), TR.getY2(), ids2, k2);
                            if (ids2[0] == 0) {
                                out.println("NIL");
                            } else {
                                Arrays.sort(ids2);
                                for (i = 10000 - k2[0]; i < 10000; i++) {
                                    if (ids2[i] != 0 && ids2[i] != ids2[i - 1] && i != 0) {
                                        if (ids2[i] == ids2[9999]) {
                                            out.println(ids2[i]);
                                        } else {
                                            out.print(ids2[i] + " ");
                                        }
                                    }
                                }
                            }
                            break;

                        case 3://Cerc
                            double coordC[] = new double[2];
                            double radius = ReadFile.nextDouble();
                            for (i = 0; i <= 1; i++) {
                                coordC[i] = ReadFile.nextDouble();
                            }
                            int[] ids3 = new int[10000];
                            int[] k3 = new int[1];
                            Circle C = new Circle(radius, coordC[0], coordC[1], 0);
                            ids3 = tree.operation4(tree, C.getX1(), C.getY1(), C.getX2(), C.getY2(), ids3, k3);
                            if (ids3[0] == 0 && ids3[1] == 0) {
                                out.println("NIL");
                            } else {
                                Arrays.sort(ids3);
                                for (i = 10000 - k3[0]; i < 10000; i++) {
                                    if (ids3[i] != 0 && ids3[i] != ids3[i - 1] && i != 0) {
                                        if (ids3[i] == ids3[9999]) {
                                            out.println(ids3[i]);
                                        } else {
                                            out.print(ids3[i] + " ");
                                        }
                                    }
                                }
                            }
                            break;

                        case 4://Romb
                            double coordRO[] = new double[8];
                            for (i = 0; i <= 7; i++) {
                                coordRO[i] = ReadFile.nextDouble();
                            }
                            int[] ids4 = new int[10000];
                            int[] k4 = new int[1];
                            Rhombus RO = new Rhombus(coordRO[0], coordRO[1], coordRO[2], coordRO[3], coordRO[4], coordRO[5], coordRO[6], coordRO[7], 0);
                            ids4 = tree.operation4(tree, RO.getX1(), RO.getY1(), RO.getX2(), RO.getY2(), ids4, k4);
                            if (ids4[1] == 0 && ids4[0] == 0) {
                                out.println("NIL");
                            } else {
                                Arrays.sort(ids4);
                                for (i = 10000 - k4[0]; i < 10000; i++) {
                                    if (ids4[i] != 0 && ids4[i] != ids4[i - 1] && i != 0) {
                                        if (ids4[i] == ids4[9999]) {
                                            out.println(ids4[i]);
                                        } else {
                                            out.print(ids4[i] + " ");
                                        }
                                    }
                                }
                            }
                            break;
                    }
                    break;
            }
        }
        ReadFile.close();
        out.close();
    }
}
