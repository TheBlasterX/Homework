/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import static java.lang.Math.pow;

/**
 *
 * @author Stefan Jipa
 * Clasa aceasta contine atributele unui cerc, constructori, get-eri si metoda Point_in cu rol de a verifica daca un punct se afla in cerc
 * get-erii returneaza coordonatele dreptunghiului incadrator
 */
public class Circle extends Quadtree {

    double radius;
    double x;
    double y;
    int idd;

/**
 * 
 * @param radius
 * @param x
 * @param y
 * @param idd
 * Constructorul cu parametrii al clasei circle: raza, x si y al
     * centrului cercului, id-ul cercului Initializeaza toate aceste atribute
     * ale clasei
 */
    public Circle(double radius, double x, double y, int idd) {
        this.radius = radius;
        this.x = x;
        this.y = y;
        this.idd = idd;
    }

    /**
     * Constructorul fara parametrii al clasei Circle
     */
    public Circle() {
    }

    /**
     * Get-er pt id
     * @return 
     */
    @Override
    public int getId() {
        return idd;
    }

    /**
     * Get-er pt X1 al dreptunghiului incadrator
     * @return 
     */
    @Override
    public double getX1() {
        return x - radius;
    }

    /**
     *Get-er pt Y1 al dreptunghiului incadrator
     * @return 
     */
    @Override
    public double getY1() {
        return y - radius;
    }

    /**
     * Get-er pt X2 al dreptunghiului incadrator
     * @return 
     */
    @Override
    public double getX2() {
        return x + radius;
    }

    /**
     * Get-er pt Y2 al dreptunghiului incadrator
     * @return 
     */
    @Override
    public double getY2() {
        return y + radius;
    }

    /**
     * 
     * @param x1
     * @param y1
     * @return 
     * Metoda ce returneaza adevarat sau fals, daca un punct se afla in cerc
     */
    @Override
    public boolean Point_in(double x1, double y1) {
        boolean ans = false;
        if (pow((x1 - x), 2) + pow((y1 - y), 2) <= pow(radius, 2)) {
            ans = true;
        }
        return ans;
    }

}
