//Jipa Alexandru-Stefan 311CB
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

/* Tells the compiler not to add padding for these structs. This may
   be useful when reading/writing to binary files.
   http://stackoverflow.com/questions/3318410/pragma-pack-effect
*/
#pragma pack(1)

typedef struct BMP_fileheader
{
    unsigned char  fileMarker1; /* 'B' */
    unsigned char  fileMarker2; /* 'M' */
    unsigned int   bfSize; /* File's size */
    unsigned short unused1;
    unsigned short unused2;
    unsigned int   imageDataOffset; /* Offset to the start of image data */
}fileh;

typedef struct BMP_infoheader
{
    unsigned int   biSize; /* Size of the info header - 40 bytes */
    signed int     width; /* Width of the image */
    signed int     height; /* Height of the image */
    unsigned short planes;
    unsigned short bitPix;
    unsigned int   biCompression;
    unsigned int   biSizeImage; /* Size of the image data */
    int            biXPelsPerMeter;
    int            biYPelsPerMeter;
    unsigned int   biClrUsed;
    unsigned int   biClrImportant;
}infoh;

#pragma pack()

typedef struct Pixel_color
{
	unsigned char b;
	unsigned char g;
	unsigned char r;
}pixeli;

int main(){
	FILE * text;
	FILE * read;
	FILE * test;
	FILE * fisier;
	read = fopen("input.txt","r");
	
	char captcha[26], captcha1[26];
	int blue, green, red, s, i;
	
	fscanf(read,"%s",captcha);
	fscanf(read,"%d %d %d",&blue,&green,&red);
	s = strlen(captcha)-4;	
	test = fopen(captcha,"rb");
	strcpy(captcha1, captcha);	
	strcpy(captcha + s,"_task1.bmp");	
	
	strcpy(captcha1 + s,"_task2.txt");
	fisier = fopen(captcha,"wb");	

	int a[100][100];
	
	infoh info_header;
	fileh file_header;
	pixeli pixel; 

	fread(&file_header,sizeof(fileh),1,test);
	fread(&info_header,sizeof(infoh),1,test);
	
	fwrite(&file_header,sizeof(fileh),1,fisier);
	fwrite(&info_header,sizeof(infoh),1,fisier);
	
	int j, k, l;
	int padding = (4 - ( (info_header.width * 3) % 4) )%4; //formula padding-ului 
	for (i = 0; i < info_header.height; i++) 
	{
		for (j = 0; j < info_header.width; j++) 
		{

			fread(&pixel,sizeof(pixeli),1,test);
			if (pixel.b != 255 || pixel.g != 255 || pixel.r != 255)
			{
				a[info_header.height - i - 1][j] = 1;
				pixel.b = blue;
				pixel.g = green;
				pixel.r = red;
			}
			else
			{	
				a[info_header.height - i - 1][j] = 0;
			}
	
			fwrite(&pixel,sizeof(pixel),1,fisier);
		}

		int zero = 0;
		fwrite(&zero,sizeof(char),padding,fisier);
		fseek(test,padding,1);
	}

	text = fopen(captcha1,"w");

	int cifra[26][25];
	int num = 0, h;
	for(i = 0 ; i < info_header.width; i++)
	{
		for(j = info_header.height; j >= 0; j--)
		{

			if(a[j][i] == 1 && a[j + 4][i] == 1 && a[j][i + 1] == 0 && a[j + 4][i + 1] == 0)
			{	
				k = 0;
				for(h = j; h <= j + 4; h++)
				 {
					for(l = i - 4; l <= i; l++)
					{							
							cifra[num][k] = a[h][l];
							k++;
					}
				}
				num++;
			}
		}
	}
	//cu acesti vectori compar cifrele obtinute din captcha
	//number_0 reprezinta cifra 0 formata din 1 si 0
	//1 pentru pixel color si 0 pentru pixel alb
	int number_0[25] =  {1,1,1,1,1,1,0,0,0,1,1,0,0,0,1,1,0,0,0,1,1,1,1,1,1};  
	int number_1[25] =  {0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};	
	int number_2[25] =  {1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1};  
	int number_3[25] =  {1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1};  
	int number_4[25] =  {1,0,0,0,1,1,0,0,0,1,1,1,1,1,1,0,0,0,0,1,0,0,0,0,1};	
	int number_5[25] =  {1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1};		 
	int number_6[25] =  {1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1};	
	int number_7[25] =  {1,1,1,1,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1};  
	int number_8[25] =  {1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,1,0,0,0,1,1,1,1,1,1};	
	int number_9[25] =  {1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1};	

	int sum_0 = 0;
	int sum_1 = 0;
	int sum_2 = 0;
	int sum_3 = 0;
	int sum_4 = 0;
	int sum_5 = 0;
	int sum_6 = 0;
	int sum_7 = 0;
	int sum_8 = 0;
	int sum_9 = 0;

	for(i = 0; i < num; i++)
	{
		
		for(j = 0; j < 25;j++){
			if(number_0[j] != cifra[i][j])
				sum_0++;
			if(number_1[j] != cifra[i][j])
				sum_1++;
			if(number_2[j] != cifra[i][j])
				sum_2++;
			if(number_3[j] != cifra[i][j])
				sum_3++;
			if(number_4[j] != cifra[i][j])
				sum_4++;
			if(number_5[j] != cifra[i][j])
				sum_5++;
			if(number_6[j] != cifra[i][j])
				sum_6++;
			if(number_7[j] != cifra[i][j])
				sum_7++;
			if(number_8[j] != cifra[i][j])
				sum_8++;
			if(number_9[j] != cifra[i][j])
				sum_9++;
		}
		if(sum_0 == 0)
			fprintf(text,"0");
		if(sum_1 == 0)
			fprintf(text,"1");
		if(sum_2 == 0)
			fprintf(text,"2");
		if(sum_3 == 0)
			fprintf(text,"3");
		if(sum_4 == 0)
			fprintf(text,"4");
		if(sum_5 == 0)
			fprintf(text,"5");
		if(sum_6 == 0)
			fprintf(text,"6");
		if(sum_7 == 0)
			fprintf(text,"7");
		if(sum_8 == 0)
			fprintf(text,"8");
		if(sum_9 == 0)
			fprintf(text,"9");
		sum_0 = 0;
		sum_1 = 0;
		sum_2 = 0;
		sum_3 = 0;
		sum_4 = 0;
		sum_5 = 0;
		sum_6 = 0;
		sum_7 = 0;
		sum_8 = 0;
		sum_9 = 0;
		
	}
			
	fclose(text);	
	fclose(test);
	fclose(fisier);
	fclose(read);
	
	return 0;
}
