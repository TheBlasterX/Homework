#include<stdio.h>



long long palindrom(long long x)

{

	long long n,inv=0;	

	n=x;

	while(x)

	{	

		inv=inv*10+x%10;

		x=x/10;

	}

	if(inv==n) return 1;

		else return 0;

}



o_cifra(long long p){

	long long i, k=0;

	for(i=1;i<=9;i++){

		if(p%i==0&&p/i>=1&&p/i<=9&&i!=p/i)

				k++;

	}	

	return k;

}			



doua_cifre(long long p){

	long long i, k=0;

	for(i=10;i<=99;i++){

		if(p%i==0&&p/i>=10&&p/i<=99&&i!=p/i)

				k++;

	}

	return k;

}



trei_cifre(long long p){

	long long i, k=0;

	for(i=100;i<=999;i++){

		if(p%i==0&&p/i>=100&&p/i<=999&&i!=p/i)

				k++;

	}	

	return k;

}



int main()

{

	long long i, x;

	int p,k=0;

	scanf("%d%llu",&p,&x);		

	if(p==1){	

		k=1;//pentru a nu-l mai verifica pe 0

		    //in functia palindrom 		

		if(x>81){ 

			for(i=1;i<=81;i++)

				if(palindrom(i))

					if(o_cifra(i))

						k++;

			printf("%d\n",k);

			}			

			else {

				for(i=1;i<x;i++)

					if(palindrom(i))

						if(o_cifra(i))

							k++;

				printf("%d\n",k);

				}

		}					

		else if(p==2)

			if(x>9801)

			{for(i=100;i<=9801;i++)

				if(palindrom(i))

					if(doua_cifre(i))

						k++;

			printf("%d\n",k);

			}

			else {

				for(i=100;i<x;i++)

					if(palindrom(i))

						if(doua_cifre(i))

							k++;

				printf("%d\n",k);

				}

		else if(p==3)

			if(x>998001)

			{for(i=10000;i<=998001;i++)

				if(palindrom(i))

					if(trei_cifre(i))

						k++;

			printf("%d\n",k);

			}

			else {

				for(i=10000;i<x;i++)

					if(palindrom(i))

						if(trei_cifre(i))

							k++;

				printf("%d\n",k);

				}	

	return 0;

}	