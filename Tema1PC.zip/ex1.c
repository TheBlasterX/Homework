#include<stdio.h>

int suma_div(int a)
{	
	int i, s = 0;
	for(i = 1;i <= a/2; i++)
	{
		if(a % i == 0)
		{
			s = s + i;
		}
	}
	return s;
}

int main()
{	
	int i, j, k, s;
	scanf("%d", &k);
	for(i = 1; i < k; i++)
	{	
		s = suma_div(i);	
		for(j = i + 1; j < k; j++)
		{	if(s == j && suma_div(j) == i)
			{	printf("%d %d\n", i, j);
	 		}
		}
	}
	return 0;
}